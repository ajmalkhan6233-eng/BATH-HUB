--
-- PostgreSQL database dump
--

\restrict pohWacphkmIg3Hpnss3VlXtAnIeHIXVEeMxmRxEkg8G5w96vr2p7eWt47nffute

-- Dumped from database version 16.15 (Ubuntu 16.15-0ubuntu0.24.04.1)
-- Dumped by pg_dump version 16.15 (Ubuntu 16.15-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: acc_bank_transactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.acc_bank_transactions (
    id integer NOT NULL,
    txn_date date,
    description text,
    amount numeric DEFAULT 0,
    txn_type text,
    bank_name text,
    notes text,
    matched boolean DEFAULT false,
    matched_ref text
);


--
-- Name: acc_bank_transactions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.acc_bank_transactions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: acc_bank_transactions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.acc_bank_transactions_id_seq OWNED BY public.acc_bank_transactions.id;


--
-- Name: acc_chart_of_accounts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.acc_chart_of_accounts (
    account_code text NOT NULL,
    account_name text,
    account_type text,
    parent_code text,
    active boolean DEFAULT true
);


--
-- Name: acc_expense_categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.acc_expense_categories (
    id integer NOT NULL,
    category_name text,
    monthly_budget numeric DEFAULT 0,
    notes text
);


--
-- Name: acc_expense_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.acc_expense_categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: acc_expense_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.acc_expense_categories_id_seq OWNED BY public.acc_expense_categories.id;


--
-- Name: acc_journal_entries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.acc_journal_entries (
    id integer NOT NULL,
    entry_date date,
    description text,
    debit_account_code text,
    credit_account_code text,
    amount numeric DEFAULT 0,
    reference text,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: acc_journal_entries_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.acc_journal_entries_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: acc_journal_entries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.acc_journal_entries_id_seq OWNED BY public.acc_journal_entries.id;


--
-- Name: acc_petty_cash_txns; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.acc_petty_cash_txns (
    id integer NOT NULL,
    txn_date date,
    txn_type text,
    amount numeric DEFAULT 0,
    description text,
    category text
);


--
-- Name: acc_petty_cash_txns_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.acc_petty_cash_txns_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: acc_petty_cash_txns_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.acc_petty_cash_txns_id_seq OWNED BY public.acc_petty_cash_txns.id;


--
-- Name: acc_year_end_closings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.acc_year_end_closings (
    id integer NOT NULL,
    fiscal_year integer,
    closing_date date DEFAULT CURRENT_DATE,
    total_revenue numeric,
    total_expenses numeric,
    net_profit numeric,
    notes text
);


--
-- Name: acc_year_end_closings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.acc_year_end_closings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: acc_year_end_closings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.acc_year_end_closings_id_seq OWNED BY public.acc_year_end_closings.id;


--
-- Name: admin_audit; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.admin_audit (
    id integer NOT NULL,
    at timestamp with time zone DEFAULT now() NOT NULL,
    actor character varying(100),
    actor_role character varying(20),
    action character varying(80) NOT NULL,
    target_type character varying(60),
    target_id character varying(100),
    detail jsonb,
    ip character varying(60)
);


--
-- Name: admin_audit_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.admin_audit_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: admin_audit_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.admin_audit_id_seq OWNED BY public.admin_audit.id;


--
-- Name: agent_checks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_checks (
    id integer NOT NULL,
    draft_id integer NOT NULL,
    kind text DEFAULT 'created'::text NOT NULL,
    intent text,
    rules_used text DEFAULT '[]'::text NOT NULL,
    reasoning text DEFAULT ''::text NOT NULL,
    checks text DEFAULT '[]'::text NOT NULL,
    passed boolean NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: agent_checks_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.agent_checks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: agent_checks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.agent_checks_id_seq OWNED BY public.agent_checks.id;


--
-- Name: agent_rules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_rules (
    id integer NOT NULL,
    rule_key integer NOT NULL,
    topic text NOT NULL,
    rule_text text NOT NULL,
    source text DEFAULT 'taught by Aj'::text NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: agent_rules_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.agent_rules_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: agent_rules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.agent_rules_id_seq OWNED BY public.agent_rules.id;


--
-- Name: alerts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alerts (
    id integer NOT NULL,
    type text,
    message text,
    priority text DEFAULT 'normal'::text,
    read boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: alerts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.alerts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: alerts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.alerts_id_seq OWNED BY public.alerts.id;


--
-- Name: app_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.app_settings (
    key text NOT NULL,
    value jsonb NOT NULL,
    updated_by text,
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: attachments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.attachments (
    id integer NOT NULL,
    record_type character varying(40) NOT NULL,
    record_id character varying(100) NOT NULL,
    filename character varying(255) NOT NULL,
    mime character varying(100) NOT NULL,
    size integer NOT NULL,
    uploaded_by character varying(100),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    stored_name character varying(80) NOT NULL,
    client_uuid character varying(64),
    removed_at timestamp with time zone,
    removed_by character varying(100)
);


--
-- Name: attachments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.attachments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: attachments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.attachments_id_seq OWNED BY public.attachments.id;


--
-- Name: audit_baseline; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_baseline (
    item_code text NOT NULL,
    stock numeric,
    grn_in numeric,
    sold numeric,
    taken_at timestamp with time zone DEFAULT now()
);


--
-- Name: audit_invoice_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_invoice_items (
    id integer NOT NULL,
    sale_date date,
    invoice_no text,
    item_code text,
    description text,
    qty numeric DEFAULT 0,
    unit_price numeric DEFAULT 0,
    line_total numeric DEFAULT 0,
    unit_cost numeric,
    line_cogs numeric,
    line_gp numeric,
    cost_source text
);


--
-- Name: audit_invoice_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.audit_invoice_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: audit_invoice_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.audit_invoice_items_id_seq OWNED BY public.audit_invoice_items.id;


--
-- Name: automation_runs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.automation_runs (
    job text NOT NULL,
    day date NOT NULL
);


--
-- Name: bank_accounts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bank_accounts (
    id integer NOT NULL,
    account_label character varying(100) NOT NULL,
    bank character varying(100),
    current_balance numeric(14,2) DEFAULT 0 NOT NULL,
    active boolean DEFAULT true NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: bank_accounts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.bank_accounts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bank_accounts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.bank_accounts_id_seq OWNED BY public.bank_accounts.id;


--
-- Name: bank_holidays; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bank_holidays (
    day date NOT NULL,
    label character varying(80)
);


--
-- Name: branches; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.branches (
    id integer NOT NULL,
    name text NOT NULL,
    agent_allowed_actions text DEFAULT 'read'::text NOT NULL,
    spend_cap_lkr numeric DEFAULT 0 NOT NULL,
    approver text DEFAULT 'Aj'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: branches_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.branches_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: branches_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.branches_id_seq OWNED BY public.branches.id;


--
-- Name: catalogue_web; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.catalogue_web (
    item_code text NOT NULL,
    size_cm text DEFAULT ''::text NOT NULL,
    finish text DEFAULT ''::text NOT NULL,
    use_case text DEFAULT ''::text NOT NULL,
    published boolean DEFAULT false NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: cheque_alerts_sent; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cheque_alerts_sent (
    cheque_id integer NOT NULL,
    alert_date date NOT NULL,
    sent_at timestamp with time zone DEFAULT now()
);


--
-- Name: cheque_deposits; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cheque_deposits (
    cheque_id integer NOT NULL,
    deposit_date date NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: cheque_personal; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cheque_personal (
    cheque_id integer NOT NULL
);


--
-- Name: cheque_register; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cheque_register (
    id integer NOT NULL,
    cheque_no character varying(50),
    bank character varying(100),
    payee character varying(150) NOT NULL,
    amount numeric(12,2) NOT NULL,
    due_date date NOT NULL,
    status character varying(20) DEFAULT 'pending'::character varying NOT NULL,
    notes text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    account_id integer,
    held_from_date date
);


--
-- Name: cheque_register_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.cheque_register_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: cheque_register_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.cheque_register_id_seq OWNED BY public.cheque_register.id;


--
-- Name: cheques; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cheques (
    id integer NOT NULL,
    customer_id integer,
    amount numeric DEFAULT 0,
    due_date date,
    bank text,
    cheque_no text,
    cheque_number text,
    status text DEFAULT 'pending'::text,
    notes text,
    created_at timestamp with time zone DEFAULT now(),
    payee character varying(150)
);


--
-- Name: cheques_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.cheques_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: cheques_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.cheques_id_seq OWNED BY public.cheques.id;


--
-- Name: competitor_checks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.competitor_checks (
    id integer NOT NULL,
    competitor_id integer NOT NULL,
    checked_on date NOT NULL,
    posts boolean,
    goes_live boolean,
    online_store boolean,
    promotions text DEFAULT ''::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: competitor_checks_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.competitor_checks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: competitor_checks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.competitor_checks_id_seq OWNED BY public.competitor_checks.id;


--
-- Name: competitors; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.competitors (
    id integer NOT NULL,
    name text NOT NULL,
    area text DEFAULT ''::text NOT NULL,
    channels text DEFAULT ''::text NOT NULL,
    last_checked date,
    notes text DEFAULT ''::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: competitors_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.competitors_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: competitors_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.competitors_id_seq OWNED BY public.competitors.id;


--
-- Name: content_posts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.content_posts (
    id integer NOT NULL,
    planned_date date NOT NULL,
    platform text NOT NULL,
    type text NOT NULL,
    script_draft text,
    status text DEFAULT 'idea'::text NOT NULL,
    posted_url text,
    enquiries_after integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: content_posts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.content_posts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: content_posts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.content_posts_id_seq OWNED BY public.content_posts.id;


--
-- Name: conversations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.conversations (
    id integer NOT NULL,
    customer_id integer,
    channel text,
    agent text,
    messages jsonb DEFAULT '[]'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: conversations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.conversations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: conversations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.conversations_id_seq OWNED BY public.conversations.id;


--
-- Name: credit_customers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.credit_customers (
    id integer NOT NULL,
    customer_id integer,
    name text,
    invoice_date date,
    invoice_no text,
    amount numeric DEFAULT 0,
    paid numeric DEFAULT 0,
    due_date date,
    notes text,
    quarantined boolean DEFAULT false
);


--
-- Name: credit_customers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.credit_customers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: credit_customers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.credit_customers_id_seq OWNED BY public.credit_customers.id;


--
-- Name: customer_credit_limits; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.customer_credit_limits (
    id integer NOT NULL,
    customer_name character varying(150) NOT NULL,
    credit_limit numeric(12,2) NOT NULL,
    notes text,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: customer_credit_limits_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.customer_credit_limits_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: customer_credit_limits_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.customer_credit_limits_id_seq OWNED BY public.customer_credit_limits.id;


--
-- Name: customers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.customers (
    id integer NOT NULL,
    name text,
    phone text,
    whatsapp text,
    location text,
    source text,
    notes text,
    last_contact timestamp with time zone DEFAULT now(),
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: customers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.customers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: customers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.customers_id_seq OWNED BY public.customers.id;


--
-- Name: daily_breakdown_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.daily_breakdown_settings (
    id integer DEFAULT 1 NOT NULL,
    rent_monthly numeric(12,2) DEFAULT 70000 NOT NULL,
    salary_monthly numeric(12,2) DEFAULT 0 NOT NULL,
    other_monthly numeric(12,2) DEFAULT 0 NOT NULL,
    commission_rate numeric(5,2) DEFAULT 5 NOT NULL,
    rent_day integer DEFAULT 0 NOT NULL,
    salary_day integer DEFAULT 0 NOT NULL,
    cheque_window_days integer DEFAULT 7 NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT daily_breakdown_settings_id_check CHECK ((id = 1))
);


--
-- Name: daily_cash_plan; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.daily_cash_plan (
    id integer NOT NULL,
    report_date date NOT NULL,
    sales_total numeric(12,2) NOT NULL,
    expenses_total numeric(12,2) DEFAULT 0 NOT NULL,
    purchasing_reserve numeric(12,2) DEFAULT 0 NOT NULL,
    notes text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: daily_cash_plan_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.daily_cash_plan_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: daily_cash_plan_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.daily_cash_plan_id_seq OWNED BY public.daily_cash_plan.id;


--
-- Name: daily_entry_live; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.daily_entry_live (
    entry_date date NOT NULL,
    payload jsonb NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_by text
);


--
-- Name: daily_payment_breakdown; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.daily_payment_breakdown (
    id integer NOT NULL,
    report_date date NOT NULL,
    mode character varying(30) NOT NULL,
    amount numeric(12,2) DEFAULT 0 NOT NULL
);


--
-- Name: daily_payment_breakdown_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.daily_payment_breakdown_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: daily_payment_breakdown_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.daily_payment_breakdown_id_seq OWNED BY public.daily_payment_breakdown.id;


--
-- Name: daily_reports; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.daily_reports (
    id integer NOT NULL,
    report_date date,
    invoice_no text,
    total_sale numeric DEFAULT 0,
    cash_amount numeric DEFAULT 0,
    card_amount numeric DEFAULT 0,
    online_amount numeric DEFAULT 0,
    cheque_amount numeric DEFAULT 0,
    credit_amount numeric DEFAULT 0,
    is_refund boolean DEFAULT false,
    notes text,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: daily_reports_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.daily_reports_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: daily_reports_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.daily_reports_id_seq OWNED BY public.daily_reports.id;


--
-- Name: daily_summary; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.daily_summary (
    id integer NOT NULL,
    report_date date NOT NULL,
    total_sale numeric DEFAULT 0,
    cash_sale numeric DEFAULT 0,
    card_sale numeric DEFAULT 0,
    online_sale numeric DEFAULT 0,
    credit_sale numeric DEFAULT 0,
    cheq_payment numeric DEFAULT 0,
    cash_received numeric DEFAULT 0,
    cash_in numeric DEFAULT 0,
    cash_out numeric DEFAULT 0,
    cash_in_hand numeric DEFAULT 0,
    total_expenses numeric DEFAULT 0,
    payments numeric DEFAULT 0,
    salary numeric DEFAULT 0,
    gross_profit numeric DEFAULT 0,
    net_profit numeric DEFAULT 0,
    gp_status text DEFAULT 'NOT_AVAILABLE'::text,
    day_status text DEFAULT 'ESTIMATED'::text,
    lasersoft_total numeric DEFAULT 0,
    manual_sale_total numeric DEFAULT 0,
    manual_gp_estimate numeric DEFAULT 0,
    gp_blend_note text,
    sales_source text,
    expenses_source text,
    source text,
    sales_conflict boolean DEFAULT false,
    sales_conflict_excel numeric,
    checker_flags jsonb DEFAULT '[]'::jsonb,
    details jsonb DEFAULT '{}'::jsonb,
    photo_data jsonb,
    notes text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    invoice_seq_start text,
    invoice_seq_end text,
    override_log jsonb DEFAULT '[]'::jsonb
);


--
-- Name: daily_summary_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.daily_summary_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: daily_summary_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.daily_summary_id_seq OWNED BY public.daily_summary.id;


--
-- Name: discount_rules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.discount_rules (
    id integer NOT NULL,
    role character varying(30) DEFAULT 'all'::character varying NOT NULL,
    max_discount_pct numeric(5,2) NOT NULL,
    notes text,
    active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: discount_rules_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.discount_rules_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: discount_rules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.discount_rules_id_seq OWNED BY public.discount_rules.id;


--
-- Name: document_inbox; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_inbox (
    id integer NOT NULL,
    source text DEFAULT 'upload'::text NOT NULL,
    from_ref text DEFAULT ''::text NOT NULL,
    original_name text DEFAULT ''::text NOT NULL,
    file_path text NOT NULL,
    doc_type text DEFAULT 'unknown'::text NOT NULL,
    status text DEFAULT 'to_check'::text NOT NULL,
    extracted text DEFAULT '{}'::text NOT NULL,
    confidence text DEFAULT ''::text NOT NULL,
    reader_note text DEFAULT ''::text NOT NULL,
    filed_to text,
    filed_id text,
    filed_note text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    filed_at timestamp with time zone,
    sha256 character varying(64)
);


--
-- Name: document_inbox_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.document_inbox_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: document_inbox_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.document_inbox_id_seq OWNED BY public.document_inbox.id;


--
-- Name: document_quarantine; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_quarantine (
    id integer NOT NULL,
    file_name character varying(80) NOT NULL,
    ext character varying(8) NOT NULL,
    mime character varying(60) NOT NULL,
    bytes integer NOT NULL,
    sha256 character varying(64) NOT NULL,
    original_name character varying(200) DEFAULT ''::character varying NOT NULL,
    source character varying(30) DEFAULT 'upload'::character varying NOT NULL,
    from_ref character varying(100) DEFAULT ''::character varying NOT NULL,
    caption character varying(300) DEFAULT ''::character varying NOT NULL,
    suggested_place character varying(30),
    suggested_reason character varying(200) DEFAULT ''::character varying NOT NULL,
    status character varying(20) DEFAULT 'quarantined'::character varying NOT NULL,
    inbox_id integer,
    created_at timestamp with time zone DEFAULT now(),
    decided_at timestamp with time zone,
    decided_by character varying(100)
);


--
-- Name: document_quarantine_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.document_quarantine_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: document_quarantine_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.document_quarantine_id_seq OWNED BY public.document_quarantine.id;


--
-- Name: document_recipients; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_recipients (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    role character varying(20) DEFAULT 'contact'::character varying NOT NULL,
    phone character varying(20) NOT NULL,
    allowed_types text DEFAULT '[]'::text NOT NULL,
    active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: document_recipients_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.document_recipients_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: document_recipients_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.document_recipients_id_seq OWNED BY public.document_recipients.id;


--
-- Name: document_sends; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_sends (
    id integer NOT NULL,
    document_id integer,
    document_title character varying(200),
    recipient_id integer,
    purpose character varying(40) DEFAULT 'share'::character varying NOT NULL,
    idempotency_key character varying(100),
    status character varying(20) NOT NULL,
    to_last3 character varying(3),
    detail text,
    requested_by character varying(100),
    queue_id integer,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: document_sends_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.document_sends_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: document_sends_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.document_sends_id_seq OWNED BY public.document_sends.id;


--
-- Name: documents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.documents (
    id integer NOT NULL,
    type character varying(40) NOT NULL,
    title character varying(200) NOT NULL,
    period character varying(40) DEFAULT ''::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    path text NOT NULL,
    sha256 character varying(64) NOT NULL,
    created_by character varying(100),
    format character varying(8) DEFAULT 'pdf'::character varying NOT NULL,
    bytes integer
);


--
-- Name: documents_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.documents_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: documents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.documents_id_seq OWNED BY public.documents.id;


--
-- Name: enquiries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.enquiries (
    id integer NOT NULL,
    date date DEFAULT CURRENT_DATE NOT NULL,
    channel text NOT NULL,
    product_interest text,
    how_found_us text,
    status text DEFAULT 'new'::text NOT NULL,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: enquiries_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.enquiries_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: enquiries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.enquiries_id_seq OWNED BY public.enquiries.id;


--
-- Name: expenses_detail; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.expenses_detail (
    id integer NOT NULL,
    report_date date,
    category text,
    description text,
    amount numeric DEFAULT 0,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: expenses_detail_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.expenses_detail_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: expenses_detail_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.expenses_detail_id_seq OWNED BY public.expenses_detail.id;


--
-- Name: feature_flags; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.feature_flags (
    id integer NOT NULL,
    module_key text NOT NULL,
    category text,
    label text,
    description text,
    is_core boolean DEFAULT false,
    enabled boolean DEFAULT false,
    built boolean DEFAULT false,
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: feature_flags_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.feature_flags_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: feature_flags_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.feature_flags_id_seq OWNED BY public.feature_flags.id;


--
-- Name: fixed_overheads; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fixed_overheads (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    monthly_amount numeric(12,2) NOT NULL,
    active boolean DEFAULT true NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: fixed_overheads_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.fixed_overheads_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: fixed_overheads_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.fixed_overheads_id_seq OWNED BY public.fixed_overheads.id;


--
-- Name: grn_bill_extra; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.grn_bill_extra (
    bill_id integer NOT NULL,
    paper_total numeric,
    lines jsonb,
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: grn_records; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.grn_records (
    id integer NOT NULL,
    grn_number text,
    supplier_id integer,
    supplier_name text,
    grn_date date,
    item_description text,
    quantity numeric,
    unit_cost numeric,
    total_amount numeric,
    source_file_path text,
    status text DEFAULT 'PENDING_REVIEW'::text,
    notes text,
    created_at timestamp with time zone DEFAULT now(),
    caveat_note text,
    caveat_flag boolean DEFAULT false
);


--
-- Name: grn_records_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.grn_records_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: grn_records_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.grn_records_id_seq OWNED BY public.grn_records.id;


--
-- Name: investor_contacts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.investor_contacts (
    id integer NOT NULL,
    phone text NOT NULL,
    name text NOT NULL,
    lender_name text NOT NULL,
    active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: investor_contacts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.investor_contacts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: investor_contacts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.investor_contacts_id_seq OWNED BY public.investor_contacts.id;


--
-- Name: investor_loan_documents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.investor_loan_documents (
    id integer NOT NULL,
    loan_id integer,
    original_name character varying(255) NOT NULL,
    stored_name character varying(255) NOT NULL,
    uploaded_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: investor_loan_documents_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.investor_loan_documents_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: investor_loan_documents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.investor_loan_documents_id_seq OWNED BY public.investor_loan_documents.id;


--
-- Name: investor_loan_payments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.investor_loan_payments (
    id integer NOT NULL,
    loan_id integer,
    amount numeric(12,2) NOT NULL,
    payment_date date NOT NULL,
    notes text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: investor_loan_payments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.investor_loan_payments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: investor_loan_payments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.investor_loan_payments_id_seq OWNED BY public.investor_loan_payments.id;


--
-- Name: investor_loans; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.investor_loans (
    id integer NOT NULL,
    lender_name character varying(150) NOT NULL,
    amount numeric(12,2) NOT NULL,
    profit_rate numeric(5,2) DEFAULT 0,
    date_given date NOT NULL,
    due_date date,
    status character varying(20) DEFAULT 'active'::character varying,
    notes text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    qr_outstanding numeric(12,2) DEFAULT 0
);


--
-- Name: investor_loans_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.investor_loans_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: investor_loans_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.investor_loans_id_seq OWNED BY public.investor_loans.id;


--
-- Name: invoice_receipts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.invoice_receipts (
    id integer NOT NULL,
    report_id integer,
    report_date date NOT NULL,
    invoice_no character varying(100),
    customer_id integer,
    customer_name character varying(200),
    customer_phone character varying(30) NOT NULL,
    status character varying(20) DEFAULT 'not_sent'::character varying NOT NULL,
    last_error text,
    sent_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    bill_id integer
);


--
-- Name: invoice_receipts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.invoice_receipts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: invoice_receipts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.invoice_receipts_id_seq OWNED BY public.invoice_receipts.id;


--
-- Name: login_audit; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.login_audit (
    id integer NOT NULL,
    username text,
    success boolean,
    ip text,
    reason text,
    attempted_at timestamp with time zone DEFAULT now()
);


--
-- Name: login_audit_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.login_audit_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: login_audit_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.login_audit_id_seq OWNED BY public.login_audit.id;


--
-- Name: market_purchases; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.market_purchases (
    id integer NOT NULL,
    purchase_date date NOT NULL,
    item character varying(200) NOT NULL,
    customer character varying(150),
    buy_cost numeric(12,2) NOT NULL,
    sell_price numeric(12,2) NOT NULL,
    bill_number character varying(30),
    note text,
    voided boolean DEFAULT false NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: market_purchases_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.market_purchases_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: market_purchases_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.market_purchases_id_seq OWNED BY public.market_purchases.id;


--
-- Name: menu_config; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.menu_config (
    item_key text NOT NULL,
    label text,
    visible boolean DEFAULT true,
    sort_order integer,
    updated_by text,
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: money_allocations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.money_allocations (
    id integer NOT NULL,
    label character varying(150) NOT NULL,
    category character varying(30) NOT NULL,
    amount numeric(12,2) NOT NULL,
    planned_date date,
    status character varying(20) DEFAULT 'planned'::character varying NOT NULL,
    notes text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: money_allocations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.money_allocations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: money_allocations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.money_allocations_id_seq OWNED BY public.money_allocations.id;


--
-- Name: notification_dismissals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notification_dismissals (
    id integer NOT NULL,
    category character varying(20) NOT NULL,
    ref_id integer NOT NULL,
    due_date date NOT NULL,
    dismissed_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: notification_dismissals_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.notification_dismissals_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: notification_dismissals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.notification_dismissals_id_seq OWNED BY public.notification_dismissals.id;


--
-- Name: notify_queue; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notify_queue (
    id integer NOT NULL,
    source text,
    body text NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    sent_day date
);


--
-- Name: notify_queue_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.notify_queue_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: notify_queue_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.notify_queue_id_seq OWNED BY public.notify_queue.id;


--
-- Name: policy_notes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.policy_notes (
    id integer NOT NULL,
    date date NOT NULL,
    topic text NOT NULL,
    summary text NOT NULL,
    source_url text DEFAULT ''::text NOT NULL,
    price_risk text DEFAULT 'med'::text NOT NULL,
    verified boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: policy_notes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.policy_notes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: policy_notes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.policy_notes_id_seq OWNED BY public.policy_notes.id;


--
-- Name: pos_bill_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pos_bill_history (
    id integer NOT NULL,
    bill_id integer NOT NULL,
    action character varying(10) NOT NULL,
    reason text,
    changed_by character varying(100),
    changed_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    old_version jsonb
);


--
-- Name: pos_bill_history_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.pos_bill_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: pos_bill_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.pos_bill_history_id_seq OWNED BY public.pos_bill_history.id;


--
-- Name: pos_bill_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pos_bill_items (
    id integer NOT NULL,
    bill_id integer,
    item_name character varying(200) NOT NULL,
    qty numeric(10,2) DEFAULT 1 NOT NULL,
    unit_price numeric(12,2) NOT NULL,
    line_total numeric(12,2) NOT NULL,
    item_code character varying(50)
);


--
-- Name: pos_bill_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.pos_bill_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: pos_bill_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.pos_bill_items_id_seq OWNED BY public.pos_bill_items.id;


--
-- Name: pos_bill_payments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pos_bill_payments (
    id integer NOT NULL,
    bill_id integer NOT NULL,
    method character varying(20) NOT NULL,
    amount numeric(12,2) NOT NULL,
    reference text
);


--
-- Name: pos_bill_payments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.pos_bill_payments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: pos_bill_payments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.pos_bill_payments_id_seq OWNED BY public.pos_bill_payments.id;


--
-- Name: pos_bill_voids; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pos_bill_voids (
    bill_id integer NOT NULL,
    reason text NOT NULL,
    voided_by character varying(100),
    voided_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    stock_restored jsonb
);


--
-- Name: pos_bills; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pos_bills (
    id integer NOT NULL,
    bill_number character varying(30) NOT NULL,
    customer_name character varying(150),
    customer_phone character varying(30),
    subtotal numeric(12,2) NOT NULL,
    discount_pct numeric(5,2) DEFAULT 0 NOT NULL,
    discount_amount numeric(12,2) DEFAULT 0 NOT NULL,
    total numeric(12,2) NOT NULL,
    payment_method character varying(30) DEFAULT 'cash'::character varying,
    notes text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    discount_override boolean DEFAULT false NOT NULL,
    source character varying(20) DEFAULT 'pos'::character varying NOT NULL,
    attachment_path text
);


--
-- Name: pos_bills_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.pos_bills_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: pos_bills_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.pos_bills_id_seq OWNED BY public.pos_bills.id;


--
-- Name: pos_cheque_registered; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pos_cheque_registered (
    payment_id integer NOT NULL,
    cheque_id integer,
    registered_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: pos_quotation_billed; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pos_quotation_billed (
    bill_id integer NOT NULL,
    quotation_id integer NOT NULL
);


--
-- Name: price_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.price_history (
    id integer NOT NULL,
    item_code text,
    old_price numeric,
    new_price numeric,
    changed_by character varying(100),
    changed_at timestamp with time zone DEFAULT now(),
    reason text
);


--
-- Name: price_history_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.price_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: price_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.price_history_id_seq OWNED BY public.price_history.id;


--
-- Name: products; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.products (
    id integer NOT NULL,
    item_code text,
    name text NOT NULL,
    category text,
    stock_level numeric DEFAULT 0,
    reorder_threshold numeric DEFAULT 0,
    selling_price numeric DEFAULT 0,
    avg_cost numeric DEFAULT 0,
    photo_url text,
    active boolean DEFAULT true,
    vendor_code text
);


--
-- Name: products_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.products_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: products_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.products_id_seq OWNED BY public.products.id;


--
-- Name: pur_landed_costs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pur_landed_costs (
    id integer NOT NULL,
    po_id integer,
    po_total numeric DEFAULT 0,
    freight numeric DEFAULT 0,
    duty numeric DEFAULT 0,
    other_costs numeric DEFAULT 0,
    total_landed_cost numeric DEFAULT 0,
    notes text,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: pur_landed_costs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.pur_landed_costs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: pur_landed_costs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.pur_landed_costs_id_seq OWNED BY public.pur_landed_costs.id;


--
-- Name: pur_purchase_orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pur_purchase_orders (
    id integer NOT NULL,
    po_number text,
    supplier_id integer,
    supplier_name text,
    po_date date,
    expected_date date,
    total_amount numeric DEFAULT 0,
    notes text,
    status text DEFAULT 'PENDING'::text,
    linked_grn_id integer,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: pur_purchase_orders_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.pur_purchase_orders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: pur_purchase_orders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.pur_purchase_orders_id_seq OWNED BY public.pur_purchase_orders.id;


--
-- Name: pur_shipments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pur_shipments (
    id integer NOT NULL,
    shipment_ref text,
    supplier_id integer,
    supplier_name text,
    po_id integer,
    origin_port text,
    eta_date date,
    status text DEFAULT 'ORDERED'::text,
    notes text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: pur_shipments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.pur_shipments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: pur_shipments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.pur_shipments_id_seq OWNED BY public.pur_shipments.id;


--
-- Name: pur_supplier_prices; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pur_supplier_prices (
    id integer NOT NULL,
    item_description text,
    supplier_id integer,
    supplier_name text,
    unit_cost numeric,
    quoted_date date,
    notes text
);


--
-- Name: pur_supplier_prices_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.pur_supplier_prices_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: pur_supplier_prices_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.pur_supplier_prices_id_seq OWNED BY public.pur_supplier_prices.id;


--
-- Name: quotation_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.quotation_items (
    id integer NOT NULL,
    quotation_id integer,
    product_id integer,
    item_code text,
    description text,
    qty numeric DEFAULT 1,
    unit_price numeric DEFAULT 0,
    line_total numeric DEFAULT 0,
    sort_order integer DEFAULT 0
);


--
-- Name: quotation_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.quotation_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: quotation_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.quotation_items_id_seq OWNED BY public.quotation_items.id;


--
-- Name: quotations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.quotations (
    id integer NOT NULL,
    customer_id integer,
    quote_date date,
    valid_until date,
    status text DEFAULT 'draft'::text,
    subtotal numeric DEFAULT 0,
    discount numeric DEFAULT 0,
    total numeric DEFAULT 0,
    notes text,
    created_by text,
    created_at timestamp with time zone DEFAULT now(),
    quote_no character varying(20)
);


--
-- Name: quotations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.quotations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: quotations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.quotations_id_seq OWNED BY public.quotations.id;


--
-- Name: receipt_images; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.receipt_images (
    id integer NOT NULL,
    queue_id integer NOT NULL,
    bill_no character varying(30),
    file_name character varying(120) NOT NULL,
    width integer,
    height integer,
    bytes integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: receipt_images_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.receipt_images_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: receipt_images_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.receipt_images_id_seq OWNED BY public.receipt_images.id;


--
-- Name: receipt_queue; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.receipt_queue (
    id integer NOT NULL,
    customer_phone character varying(30) NOT NULL,
    sale_reference text,
    amount numeric(12,2),
    status character varying(20) DEFAULT 'queued'::character varying NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    sent_at timestamp without time zone
);


--
-- Name: receipt_queue_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.receipt_queue_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: receipt_queue_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.receipt_queue_id_seq OWNED BY public.receipt_queue.id;


--
-- Name: record_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.record_history (
    id integer NOT NULL,
    module character varying(40),
    record_id character varying(100),
    action character varying(10),
    changed_by character varying(100),
    changed_at timestamp with time zone DEFAULT now(),
    reason text,
    old_version jsonb,
    new_version jsonb
);


--
-- Name: record_history_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.record_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: record_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.record_history_id_seq OWNED BY public.record_history.id;


--
-- Name: record_voids; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.record_voids (
    id integer NOT NULL,
    module character varying(40),
    record_id character varying(100),
    reason text NOT NULL,
    voided_by character varying(100),
    voided_at timestamp with time zone DEFAULT now()
);


--
-- Name: record_voids_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.record_voids_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: record_voids_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.record_voids_id_seq OWNED BY public.record_voids.id;


--
-- Name: reply_drafts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.reply_drafts (
    id integer NOT NULL,
    channel text NOT NULL,
    customer_ref text DEFAULT ''::text NOT NULL,
    incoming_text text DEFAULT ''::text NOT NULL,
    draft_text text NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    approved_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: reply_drafts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.reply_drafts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: reply_drafts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.reply_drafts_id_seq OWNED BY public.reply_drafts.id;


--
-- Name: sal_cheque_cover; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sal_cheque_cover (
    cheque_id integer NOT NULL,
    covered_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: sal_month_close; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sal_month_close (
    ym text NOT NULL,
    net numeric NOT NULL,
    savings numeric NOT NULL,
    colleague numeric NOT NULL,
    owner_comm numeric NOT NULL,
    keep numeric NOT NULL,
    adj_applied text DEFAULT '{}'::text NOT NULL,
    closed_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: sal_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sal_settings (
    key text NOT NULL,
    value numeric NOT NULL
);


--
-- Name: sal_setup_costs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sal_setup_costs (
    id integer NOT NULL,
    label text NOT NULL,
    amount numeric NOT NULL,
    paid_on date NOT NULL,
    status text DEFAULT 'paid'::text NOT NULL,
    note text
);


--
-- Name: sal_setup_costs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sal_setup_costs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sal_setup_costs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sal_setup_costs_id_seq OWNED BY public.sal_setup_costs.id;


--
-- Name: sale_commissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sale_commissions (
    id integer NOT NULL,
    staff_id integer,
    entry_type character varying(20) NOT NULL,
    sale_date date NOT NULL,
    amount numeric(12,2) NOT NULL,
    commission_pct numeric(5,2) DEFAULT 0 NOT NULL,
    commission_amount numeric(12,2) NOT NULL,
    linked_sale_id integer,
    reference_note text,
    notes text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: sale_commissions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sale_commissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sale_commissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sale_commissions_id_seq OWNED BY public.sale_commissions.id;


--
-- Name: session; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.session (
    sid character varying NOT NULL,
    sess json NOT NULL,
    expire timestamp(6) without time zone NOT NULL
);


--
-- Name: site_text; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.site_text (
    key character varying(40) NOT NULL,
    value text DEFAULT ''::text NOT NULL
);


--
-- Name: site_tiles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.site_tiles (
    id integer NOT NULL,
    name character varying(80) NOT NULL,
    size character varying(40),
    finish character varying(12) DEFAULT 'matt'::character varying NOT NULL,
    grp character varying(8) DEFAULT 'stone'::character varying NOT NULL,
    photo_file character varying(60),
    visible boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: site_tiles_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.site_tiles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: site_tiles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.site_tiles_id_seq OWNED BY public.site_tiles.id;


--
-- Name: staff; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.staff (
    id integer NOT NULL,
    name text NOT NULL,
    phone text,
    role text,
    base_salary numeric DEFAULT 0,
    commission_pct numeric DEFAULT 0,
    join_date date,
    active boolean DEFAULT true
);


--
-- Name: staff_attendance; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.staff_attendance (
    id integer NOT NULL,
    staff_id integer,
    work_date date NOT NULL,
    status character varying(20) DEFAULT 'present'::character varying,
    notes text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: staff_attendance_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.staff_attendance_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: staff_attendance_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.staff_attendance_id_seq OWNED BY public.staff_attendance.id;


--
-- Name: staff_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.staff_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: staff_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.staff_id_seq OWNED BY public.staff.id;


--
-- Name: staff_leave; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.staff_leave (
    id integer NOT NULL,
    staff_id integer,
    leave_start date NOT NULL,
    leave_end date NOT NULL,
    leave_type character varying(30) DEFAULT 'casual'::character varying,
    reason text,
    status character varying(20) DEFAULT 'approved'::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: staff_leave_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.staff_leave_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: staff_leave_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.staff_leave_id_seq OWNED BY public.staff_leave.id;


--
-- Name: staff_loans; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.staff_loans (
    id integer NOT NULL,
    staff_id integer,
    loan_date date,
    amount numeric,
    repaid numeric DEFAULT 0,
    type text DEFAULT 'loan'::text,
    notes text
);


--
-- Name: staff_loans_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.staff_loans_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: staff_loans_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.staff_loans_id_seq OWNED BY public.staff_loans.id;


--
-- Name: staff_salary; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.staff_salary (
    id integer NOT NULL,
    staff_id integer,
    pay_date date,
    amount numeric DEFAULT 0,
    commission numeric DEFAULT 0,
    period_start date,
    period_end date,
    notes text
);


--
-- Name: staff_salary_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.staff_salary_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: staff_salary_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.staff_salary_id_seq OWNED BY public.staff_salary.id;


--
-- Name: stock_adjustments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_adjustments (
    id integer NOT NULL,
    stock_item_id integer,
    delta numeric(12,2) NOT NULL,
    reason character varying(30) NOT NULL,
    notes text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: stock_adjustments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.stock_adjustments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: stock_adjustments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.stock_adjustments_id_seq OWNED BY public.stock_adjustments.id;


--
-- Name: stock_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_items (
    id integer NOT NULL,
    item_name character varying(150) NOT NULL,
    unit character varying(30) DEFAULT 'pcs'::character varying,
    current_qty numeric(12,2) DEFAULT 0 NOT NULL,
    reorder_level numeric(12,2) DEFAULT 0 NOT NULL,
    notes text,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: stock_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.stock_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: stock_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.stock_items_id_seq OWNED BY public.stock_items.id;


--
-- Name: supplier_payments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.supplier_payments (
    id integer NOT NULL,
    supplier_id integer,
    amount numeric DEFAULT 0,
    pay_date date,
    method text,
    notes text
);


--
-- Name: supplier_payments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.supplier_payments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: supplier_payments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.supplier_payments_id_seq OWNED BY public.supplier_payments.id;


--
-- Name: suppliers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.suppliers (
    id integer NOT NULL,
    name text,
    phone text,
    category text,
    notes text,
    active boolean DEFAULT true,
    contact_person text,
    whatsapp text,
    email text,
    address text,
    city text,
    tin text,
    default_credit_days integer,
    pay_note text
);


--
-- Name: suppliers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.suppliers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: suppliers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.suppliers_id_seq OWNED BY public.suppliers.id;


--
-- Name: sync_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sync_log (
    id uuid NOT NULL,
    record_type text,
    status text NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    method text,
    path text,
    response_status integer,
    response_body jsonb,
    device text,
    queued_at timestamp with time zone,
    detail jsonb,
    resolved_by text,
    resolved_at timestamp with time zone
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username text NOT NULL,
    name text,
    password_hash text NOT NULL,
    role text DEFAULT 'staff'::text NOT NULL,
    staff_id integer,
    active boolean DEFAULT true NOT NULL,
    totp_secret text,
    totp_enabled boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: vendor_bill_cheques; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vendor_bill_cheques (
    id integer NOT NULL,
    branch_id integer DEFAULT 1 NOT NULL,
    bill_id integer NOT NULL,
    cheque_no text,
    bank text,
    payee text,
    amount numeric(14,2) NOT NULL,
    cheque_date date NOT NULL,
    due_date date NOT NULL,
    same_bank boolean DEFAULT false NOT NULL,
    status text DEFAULT 'ISSUED'::text NOT NULL,
    cleared_at timestamp with time zone,
    photo_path text,
    created_by text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT vendor_bill_cheques_amount_check CHECK ((amount > (0)::numeric)),
    CONSTRAINT vendor_bill_cheques_status_check CHECK ((status = ANY (ARRAY['ISSUED'::text, 'CLEARED'::text, 'BOUNCED'::text, 'CANCELLED'::text])))
);


--
-- Name: vendor_bill_cheques_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.vendor_bill_cheques_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: vendor_bill_cheques_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.vendor_bill_cheques_id_seq OWNED BY public.vendor_bill_cheques.id;


--
-- Name: vendor_bills; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vendor_bills (
    id integer NOT NULL,
    branch_id integer DEFAULT 1 NOT NULL,
    vendor_name text NOT NULL,
    bill_no text,
    bill_date date NOT NULL,
    due_date date,
    total numeric(14,2) NOT NULL,
    grn_id integer,
    photo_path text,
    notes text,
    voided boolean DEFAULT false NOT NULL,
    created_by text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT vendor_bills_total_check CHECK ((total > (0)::numeric))
);


--
-- Name: vendor_bills_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.vendor_bills_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: vendor_bills_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.vendor_bills_id_seq OWNED BY public.vendor_bills.id;


--
-- Name: vendor_credit_notes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vendor_credit_notes (
    id integer NOT NULL,
    branch_id integer DEFAULT 1 NOT NULL,
    bill_id integer NOT NULL,
    note_no text,
    amount numeric(14,2) NOT NULL,
    note_date date NOT NULL,
    reason text,
    created_by text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT vendor_credit_notes_amount_check CHECK ((amount > (0)::numeric))
);


--
-- Name: vendor_credit_notes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.vendor_credit_notes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: vendor_credit_notes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.vendor_credit_notes_id_seq OWNED BY public.vendor_credit_notes.id;


--
-- Name: vendor_payments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vendor_payments (
    id integer NOT NULL,
    branch_id integer DEFAULT 1 NOT NULL,
    bill_id integer NOT NULL,
    amount numeric(14,2) NOT NULL,
    method text DEFAULT 'CASH'::text NOT NULL,
    paid_at date NOT NULL,
    note text,
    created_by text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT vendor_payments_amount_check CHECK ((amount > (0)::numeric))
);


--
-- Name: vendor_payments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.vendor_payments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: vendor_payments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.vendor_payments_id_seq OWNED BY public.vendor_payments.id;


--
-- Name: vendor_pending_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vendor_pending_items (
    id integer NOT NULL,
    bill_no text NOT NULL,
    vendor_name text,
    ref text,
    item_name text NOT NULL,
    qty numeric NOT NULL,
    unit_cost numeric DEFAULT 0 NOT NULL,
    amount numeric DEFAULT 0 NOT NULL,
    status text DEFAULT 'WAITING'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    delivered_at timestamp with time zone,
    note text,
    CONSTRAINT vendor_pending_items_qty_check CHECK ((qty > (0)::numeric))
);


--
-- Name: vendor_pending_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.vendor_pending_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: vendor_pending_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.vendor_pending_items_id_seq OWNED BY public.vendor_pending_items.id;


--
-- Name: viewer_access_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.viewer_access_requests (
    id integer NOT NULL,
    requester_name character varying(150) NOT NULL,
    requester_contact character varying(150),
    status character varying(20) DEFAULT 'pending'::character varying NOT NULL,
    access_token character varying(64),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    approved_at timestamp without time zone
);


--
-- Name: viewer_access_requests_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.viewer_access_requests_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: viewer_access_requests_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.viewer_access_requests_id_seq OWNED BY public.viewer_access_requests.id;


--
-- Name: whatsapp_draft_entries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.whatsapp_draft_entries (
    id integer NOT NULL,
    from_number text,
    photo_path text,
    report_date date,
    total_sale numeric,
    cash_sale numeric,
    card_sale numeric,
    online_sale numeric,
    credit_sale numeric,
    total_expenses numeric,
    expense_items text,
    confidence text,
    ocr_notes text,
    ocr_raw jsonb,
    status text DEFAULT 'PENDING_CONFIRM'::text,
    confirmed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: whatsapp_draft_entries_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.whatsapp_draft_entries_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: whatsapp_draft_entries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.whatsapp_draft_entries_id_seq OWNED BY public.whatsapp_draft_entries.id;


--
-- Name: whatsapp_notified; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.whatsapp_notified (
    id integer NOT NULL,
    category character varying(20) NOT NULL,
    ref_id integer NOT NULL,
    due_date date NOT NULL,
    notified_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: whatsapp_notified_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.whatsapp_notified_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: whatsapp_notified_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.whatsapp_notified_id_seq OWNED BY public.whatsapp_notified.id;


--
-- Name: acc_bank_transactions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.acc_bank_transactions ALTER COLUMN id SET DEFAULT nextval('public.acc_bank_transactions_id_seq'::regclass);


--
-- Name: acc_expense_categories id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.acc_expense_categories ALTER COLUMN id SET DEFAULT nextval('public.acc_expense_categories_id_seq'::regclass);


--
-- Name: acc_journal_entries id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.acc_journal_entries ALTER COLUMN id SET DEFAULT nextval('public.acc_journal_entries_id_seq'::regclass);


--
-- Name: acc_petty_cash_txns id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.acc_petty_cash_txns ALTER COLUMN id SET DEFAULT nextval('public.acc_petty_cash_txns_id_seq'::regclass);


--
-- Name: acc_year_end_closings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.acc_year_end_closings ALTER COLUMN id SET DEFAULT nextval('public.acc_year_end_closings_id_seq'::regclass);


--
-- Name: admin_audit id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_audit ALTER COLUMN id SET DEFAULT nextval('public.admin_audit_id_seq'::regclass);


--
-- Name: agent_checks id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_checks ALTER COLUMN id SET DEFAULT nextval('public.agent_checks_id_seq'::regclass);


--
-- Name: agent_rules id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_rules ALTER COLUMN id SET DEFAULT nextval('public.agent_rules_id_seq'::regclass);


--
-- Name: alerts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alerts ALTER COLUMN id SET DEFAULT nextval('public.alerts_id_seq'::regclass);


--
-- Name: attachments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attachments ALTER COLUMN id SET DEFAULT nextval('public.attachments_id_seq'::regclass);


--
-- Name: audit_invoice_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_invoice_items ALTER COLUMN id SET DEFAULT nextval('public.audit_invoice_items_id_seq'::regclass);


--
-- Name: bank_accounts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bank_accounts ALTER COLUMN id SET DEFAULT nextval('public.bank_accounts_id_seq'::regclass);


--
-- Name: branches id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.branches ALTER COLUMN id SET DEFAULT nextval('public.branches_id_seq'::regclass);


--
-- Name: cheque_register id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cheque_register ALTER COLUMN id SET DEFAULT nextval('public.cheque_register_id_seq'::regclass);


--
-- Name: cheques id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cheques ALTER COLUMN id SET DEFAULT nextval('public.cheques_id_seq'::regclass);


--
-- Name: competitor_checks id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.competitor_checks ALTER COLUMN id SET DEFAULT nextval('public.competitor_checks_id_seq'::regclass);


--
-- Name: competitors id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.competitors ALTER COLUMN id SET DEFAULT nextval('public.competitors_id_seq'::regclass);


--
-- Name: content_posts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.content_posts ALTER COLUMN id SET DEFAULT nextval('public.content_posts_id_seq'::regclass);


--
-- Name: conversations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conversations ALTER COLUMN id SET DEFAULT nextval('public.conversations_id_seq'::regclass);


--
-- Name: credit_customers id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credit_customers ALTER COLUMN id SET DEFAULT nextval('public.credit_customers_id_seq'::regclass);


--
-- Name: customer_credit_limits id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_credit_limits ALTER COLUMN id SET DEFAULT nextval('public.customer_credit_limits_id_seq'::regclass);


--
-- Name: customers id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customers ALTER COLUMN id SET DEFAULT nextval('public.customers_id_seq'::regclass);


--
-- Name: daily_cash_plan id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.daily_cash_plan ALTER COLUMN id SET DEFAULT nextval('public.daily_cash_plan_id_seq'::regclass);


--
-- Name: daily_payment_breakdown id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.daily_payment_breakdown ALTER COLUMN id SET DEFAULT nextval('public.daily_payment_breakdown_id_seq'::regclass);


--
-- Name: daily_reports id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.daily_reports ALTER COLUMN id SET DEFAULT nextval('public.daily_reports_id_seq'::regclass);


--
-- Name: daily_summary id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.daily_summary ALTER COLUMN id SET DEFAULT nextval('public.daily_summary_id_seq'::regclass);


--
-- Name: discount_rules id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.discount_rules ALTER COLUMN id SET DEFAULT nextval('public.discount_rules_id_seq'::regclass);


--
-- Name: document_inbox id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_inbox ALTER COLUMN id SET DEFAULT nextval('public.document_inbox_id_seq'::regclass);


--
-- Name: document_quarantine id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_quarantine ALTER COLUMN id SET DEFAULT nextval('public.document_quarantine_id_seq'::regclass);


--
-- Name: document_recipients id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_recipients ALTER COLUMN id SET DEFAULT nextval('public.document_recipients_id_seq'::regclass);


--
-- Name: document_sends id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_sends ALTER COLUMN id SET DEFAULT nextval('public.document_sends_id_seq'::regclass);


--
-- Name: documents id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents ALTER COLUMN id SET DEFAULT nextval('public.documents_id_seq'::regclass);


--
-- Name: enquiries id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.enquiries ALTER COLUMN id SET DEFAULT nextval('public.enquiries_id_seq'::regclass);


--
-- Name: expenses_detail id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.expenses_detail ALTER COLUMN id SET DEFAULT nextval('public.expenses_detail_id_seq'::regclass);


--
-- Name: feature_flags id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feature_flags ALTER COLUMN id SET DEFAULT nextval('public.feature_flags_id_seq'::regclass);


--
-- Name: fixed_overheads id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fixed_overheads ALTER COLUMN id SET DEFAULT nextval('public.fixed_overheads_id_seq'::regclass);


--
-- Name: grn_records id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.grn_records ALTER COLUMN id SET DEFAULT nextval('public.grn_records_id_seq'::regclass);


--
-- Name: investor_contacts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.investor_contacts ALTER COLUMN id SET DEFAULT nextval('public.investor_contacts_id_seq'::regclass);


--
-- Name: investor_loan_documents id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.investor_loan_documents ALTER COLUMN id SET DEFAULT nextval('public.investor_loan_documents_id_seq'::regclass);


--
-- Name: investor_loan_payments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.investor_loan_payments ALTER COLUMN id SET DEFAULT nextval('public.investor_loan_payments_id_seq'::regclass);


--
-- Name: investor_loans id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.investor_loans ALTER COLUMN id SET DEFAULT nextval('public.investor_loans_id_seq'::regclass);


--
-- Name: invoice_receipts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_receipts ALTER COLUMN id SET DEFAULT nextval('public.invoice_receipts_id_seq'::regclass);


--
-- Name: login_audit id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.login_audit ALTER COLUMN id SET DEFAULT nextval('public.login_audit_id_seq'::regclass);


--
-- Name: market_purchases id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.market_purchases ALTER COLUMN id SET DEFAULT nextval('public.market_purchases_id_seq'::regclass);


--
-- Name: money_allocations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.money_allocations ALTER COLUMN id SET DEFAULT nextval('public.money_allocations_id_seq'::regclass);


--
-- Name: notification_dismissals id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_dismissals ALTER COLUMN id SET DEFAULT nextval('public.notification_dismissals_id_seq'::regclass);


--
-- Name: notify_queue id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notify_queue ALTER COLUMN id SET DEFAULT nextval('public.notify_queue_id_seq'::regclass);


--
-- Name: policy_notes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.policy_notes ALTER COLUMN id SET DEFAULT nextval('public.policy_notes_id_seq'::regclass);


--
-- Name: pos_bill_history id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_bill_history ALTER COLUMN id SET DEFAULT nextval('public.pos_bill_history_id_seq'::regclass);


--
-- Name: pos_bill_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_bill_items ALTER COLUMN id SET DEFAULT nextval('public.pos_bill_items_id_seq'::regclass);


--
-- Name: pos_bill_payments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_bill_payments ALTER COLUMN id SET DEFAULT nextval('public.pos_bill_payments_id_seq'::regclass);


--
-- Name: pos_bills id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_bills ALTER COLUMN id SET DEFAULT nextval('public.pos_bills_id_seq'::regclass);


--
-- Name: price_history id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.price_history ALTER COLUMN id SET DEFAULT nextval('public.price_history_id_seq'::regclass);


--
-- Name: products id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products ALTER COLUMN id SET DEFAULT nextval('public.products_id_seq'::regclass);


--
-- Name: pur_landed_costs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pur_landed_costs ALTER COLUMN id SET DEFAULT nextval('public.pur_landed_costs_id_seq'::regclass);


--
-- Name: pur_purchase_orders id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pur_purchase_orders ALTER COLUMN id SET DEFAULT nextval('public.pur_purchase_orders_id_seq'::regclass);


--
-- Name: pur_shipments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pur_shipments ALTER COLUMN id SET DEFAULT nextval('public.pur_shipments_id_seq'::regclass);


--
-- Name: pur_supplier_prices id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pur_supplier_prices ALTER COLUMN id SET DEFAULT nextval('public.pur_supplier_prices_id_seq'::regclass);


--
-- Name: quotation_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quotation_items ALTER COLUMN id SET DEFAULT nextval('public.quotation_items_id_seq'::regclass);


--
-- Name: quotations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quotations ALTER COLUMN id SET DEFAULT nextval('public.quotations_id_seq'::regclass);


--
-- Name: receipt_images id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.receipt_images ALTER COLUMN id SET DEFAULT nextval('public.receipt_images_id_seq'::regclass);


--
-- Name: receipt_queue id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.receipt_queue ALTER COLUMN id SET DEFAULT nextval('public.receipt_queue_id_seq'::regclass);


--
-- Name: record_history id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.record_history ALTER COLUMN id SET DEFAULT nextval('public.record_history_id_seq'::regclass);


--
-- Name: record_voids id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.record_voids ALTER COLUMN id SET DEFAULT nextval('public.record_voids_id_seq'::regclass);


--
-- Name: reply_drafts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reply_drafts ALTER COLUMN id SET DEFAULT nextval('public.reply_drafts_id_seq'::regclass);


--
-- Name: sal_setup_costs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sal_setup_costs ALTER COLUMN id SET DEFAULT nextval('public.sal_setup_costs_id_seq'::regclass);


--
-- Name: sale_commissions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sale_commissions ALTER COLUMN id SET DEFAULT nextval('public.sale_commissions_id_seq'::regclass);


--
-- Name: site_tiles id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.site_tiles ALTER COLUMN id SET DEFAULT nextval('public.site_tiles_id_seq'::regclass);


--
-- Name: staff id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.staff ALTER COLUMN id SET DEFAULT nextval('public.staff_id_seq'::regclass);


--
-- Name: staff_attendance id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.staff_attendance ALTER COLUMN id SET DEFAULT nextval('public.staff_attendance_id_seq'::regclass);


--
-- Name: staff_leave id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.staff_leave ALTER COLUMN id SET DEFAULT nextval('public.staff_leave_id_seq'::regclass);


--
-- Name: staff_loans id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.staff_loans ALTER COLUMN id SET DEFAULT nextval('public.staff_loans_id_seq'::regclass);


--
-- Name: staff_salary id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.staff_salary ALTER COLUMN id SET DEFAULT nextval('public.staff_salary_id_seq'::regclass);


--
-- Name: stock_adjustments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_adjustments ALTER COLUMN id SET DEFAULT nextval('public.stock_adjustments_id_seq'::regclass);


--
-- Name: stock_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_items ALTER COLUMN id SET DEFAULT nextval('public.stock_items_id_seq'::regclass);


--
-- Name: supplier_payments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supplier_payments ALTER COLUMN id SET DEFAULT nextval('public.supplier_payments_id_seq'::regclass);


--
-- Name: suppliers id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.suppliers ALTER COLUMN id SET DEFAULT nextval('public.suppliers_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: vendor_bill_cheques id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vendor_bill_cheques ALTER COLUMN id SET DEFAULT nextval('public.vendor_bill_cheques_id_seq'::regclass);


--
-- Name: vendor_bills id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vendor_bills ALTER COLUMN id SET DEFAULT nextval('public.vendor_bills_id_seq'::regclass);


--
-- Name: vendor_credit_notes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vendor_credit_notes ALTER COLUMN id SET DEFAULT nextval('public.vendor_credit_notes_id_seq'::regclass);


--
-- Name: vendor_payments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vendor_payments ALTER COLUMN id SET DEFAULT nextval('public.vendor_payments_id_seq'::regclass);


--
-- Name: vendor_pending_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vendor_pending_items ALTER COLUMN id SET DEFAULT nextval('public.vendor_pending_items_id_seq'::regclass);


--
-- Name: viewer_access_requests id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.viewer_access_requests ALTER COLUMN id SET DEFAULT nextval('public.viewer_access_requests_id_seq'::regclass);


--
-- Name: whatsapp_draft_entries id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.whatsapp_draft_entries ALTER COLUMN id SET DEFAULT nextval('public.whatsapp_draft_entries_id_seq'::regclass);


--
-- Name: whatsapp_notified id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.whatsapp_notified ALTER COLUMN id SET DEFAULT nextval('public.whatsapp_notified_id_seq'::regclass);


--
-- Data for Name: acc_bank_transactions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.acc_bank_transactions (id, txn_date, description, amount, txn_type, bank_name, notes, matched, matched_ref) FROM stdin;
\.


--
-- Data for Name: acc_chart_of_accounts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.acc_chart_of_accounts (account_code, account_name, account_type, parent_code, active) FROM stdin;
1000	Cash	ASSET	\N	t
1100	Bank	ASSET	\N	t
1200	Stock	ASSET	\N	t
2000	Suppliers payable	LIABILITY	\N	t
3000	Owner equity	EQUITY	\N	t
4000	Sales	INCOME	\N	t
5000	Cost of goods	EXPENSE	\N	t
6000	Running expenses	EXPENSE	\N	t
\.


--
-- Data for Name: acc_expense_categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.acc_expense_categories (id, category_name, monthly_budget, notes) FROM stdin;
\.


--
-- Data for Name: acc_journal_entries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.acc_journal_entries (id, entry_date, description, debit_account_code, credit_account_code, amount, reference, created_at) FROM stdin;
\.


--
-- Data for Name: acc_petty_cash_txns; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.acc_petty_cash_txns (id, txn_date, txn_type, amount, description, category) FROM stdin;
\.


--
-- Data for Name: acc_year_end_closings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.acc_year_end_closings (id, fiscal_year, closing_date, total_revenue, total_expenses, net_profit, notes) FROM stdin;
\.


--
-- Data for Name: admin_audit; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.admin_audit (id, at, actor, actor_role, action, target_type, target_id, detail, ip) FROM stdin;
\.


--
-- Data for Name: agent_checks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agent_checks (id, draft_id, kind, intent, rules_used, reasoning, checks, passed, created_at) FROM stdin;
\.


--
-- Data for Name: agent_rules; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agent_rules (id, rule_key, topic, rule_text, source, version, active, created_at) FROM stdin;
1	1	commission	Commission is paid weekly, calculated on net sales.	taught by Aj	1	t	2026-11-04 11:43:32.323789+00
2	2	exchange	An exchange reverses the original commission, then reapplies commission on the new sale.	taught by Aj	1	t	2026-11-04 11:43:32.34284+00
3	3	returns	The 15-day return window is a soft flag only: flag the sale, do not block it. Aj decides.	taught by Aj	1	t	2026-11-04 11:43:32.355293+00
4	4	overhead	Overhead reserve = monthly overhead total / days in the month, set aside per day.	taught by Aj	1	t	2026-11-04 11:43:32.363207+00
5	5	cheques	A held cheque shows its old date crossed out beside the new date.	taught by Aj	1	t	2026-11-04 11:43:32.375339+00
\.


--
-- Data for Name: alerts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.alerts (id, type, message, priority, read, created_at) FROM stdin;
\.


--
-- Data for Name: app_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.app_settings (key, value, updated_by, updated_at) FROM stdin;
\.


--
-- Data for Name: attachments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.attachments (id, record_type, record_id, filename, mime, size, uploaded_by, created_at, stored_name, client_uuid, removed_at, removed_by) FROM stdin;
\.


--
-- Data for Name: audit_baseline; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.audit_baseline (item_code, stock, grn_in, sold, taken_at) FROM stdin;
901	5	0	0	2026-11-04 11:55:13.499581+00
\.


--
-- Data for Name: audit_invoice_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.audit_invoice_items (id, sale_date, invoice_no, item_code, description, qty, unit_price, line_total, unit_cost, line_cogs, line_gp, cost_source) FROM stdin;
\.


--
-- Data for Name: automation_runs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.automation_runs (job, day) FROM stdin;
morning_brief	2026-11-04
bounced_help	2026-11-04
review_requests	2026-11-04
deliveries	2026-11-04
slow_stock	2026-11-04
morning_checklist	2026-11-04
hot_leads	2026-11-04
\.


--
-- Data for Name: bank_accounts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.bank_accounts (id, account_label, bank, current_balance, active, updated_at) FROM stdin;
\.


--
-- Data for Name: bank_holidays; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.bank_holidays (day, label) FROM stdin;
\.


--
-- Data for Name: branches; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.branches (id, name, agent_allowed_actions, spend_cap_lkr, approver, created_at) FROM stdin;
\.


--
-- Data for Name: catalogue_web; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.catalogue_web (item_code, size_cm, finish, use_case, published, updated_at) FROM stdin;
\.


--
-- Data for Name: cheque_alerts_sent; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cheque_alerts_sent (cheque_id, alert_date, sent_at) FROM stdin;
\.


--
-- Data for Name: cheque_deposits; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cheque_deposits (cheque_id, deposit_date, created_at) FROM stdin;
\.


--
-- Data for Name: cheque_personal; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cheque_personal (cheque_id) FROM stdin;
\.


--
-- Data for Name: cheque_register; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cheque_register (id, cheque_no, bank, payee, amount, due_date, status, notes, created_at, updated_at, account_id, held_from_date) FROM stdin;
\.


--
-- Data for Name: cheques; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cheques (id, customer_id, amount, due_date, bank, cheque_no, cheque_number, status, notes, created_at, payee) FROM stdin;
\.


--
-- Data for Name: competitor_checks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.competitor_checks (id, competitor_id, checked_on, posts, goes_live, online_store, promotions, created_at) FROM stdin;
\.


--
-- Data for Name: competitors; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.competitors (id, name, area, channels, last_checked, notes, created_at) FROM stdin;
1	Thihariya Tile Center & Granite Designers	thihariya strip		\N		2026-11-04 11:43:32.385916+00
2	Sonic Ceramic			\N		2026-11-04 11:43:32.389257+00
3	Macktiles retailers			\N		2026-11-04 11:43:32.393491+00
4	Tile Gallery			\N		2026-11-04 11:43:32.394837+00
5	Choice Ceramic			\N		2026-11-04 11:43:32.39614+00
6	Ultra Tiles			\N		2026-11-04 11:43:32.400688+00
7	Tile City			\N		2026-11-04 11:43:32.403921+00
8	Cheap Ceramics			\N		2026-11-04 11:43:32.405043+00
9	Tile Mahagedara			\N	Location unconfirmed.	2026-11-04 11:43:32.406031+00
10	Greenly			\N	Not found; spelling unconfirmed.	2026-11-04 11:43:32.406928+00
11	New Sun Ceramics	nawala		\N		2026-11-04 11:43:32.408048+00
12	Ceylon Bathware	Nugegoda		\N		2026-11-04 11:43:32.408751+00
13	Fazaal Hardware	Galle		\N		2026-11-04 11:43:32.414586+00
\.


--
-- Data for Name: content_posts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.content_posts (id, planned_date, platform, type, script_draft, status, posted_url, enquiries_after, created_at) FROM stdin;
\.


--
-- Data for Name: conversations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.conversations (id, customer_id, channel, agent, messages, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: credit_customers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.credit_customers (id, customer_id, name, invoice_date, invoice_no, amount, paid, due_date, notes, quarantined) FROM stdin;
\.


--
-- Data for Name: customer_credit_limits; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.customer_credit_limits (id, customer_name, credit_limit, notes, updated_at) FROM stdin;
\.


--
-- Data for Name: customers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.customers (id, name, phone, whatsapp, location, source, notes, last_contact, created_at) FROM stdin;
\.


--
-- Data for Name: daily_breakdown_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.daily_breakdown_settings (id, rent_monthly, salary_monthly, other_monthly, commission_rate, rent_day, salary_day, cheque_window_days, updated_at) FROM stdin;
1	70000.00	0.00	0.00	5.00	0	0	7	2026-11-04 17:09:31.488267
\.


--
-- Data for Name: daily_cash_plan; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.daily_cash_plan (id, report_date, sales_total, expenses_total, purchasing_reserve, notes, created_at) FROM stdin;
\.


--
-- Data for Name: daily_entry_live; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.daily_entry_live (entry_date, payload, updated_at, updated_by) FROM stdin;
\.


--
-- Data for Name: daily_payment_breakdown; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.daily_payment_breakdown (id, report_date, mode, amount) FROM stdin;
\.


--
-- Data for Name: daily_reports; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.daily_reports (id, report_date, invoice_no, total_sale, cash_amount, card_amount, online_amount, cheque_amount, credit_amount, is_refund, notes, created_at) FROM stdin;
\.


--
-- Data for Name: daily_summary; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.daily_summary (id, report_date, total_sale, cash_sale, card_sale, online_sale, credit_sale, cheq_payment, cash_received, cash_in, cash_out, cash_in_hand, total_expenses, payments, salary, gross_profit, net_profit, gp_status, day_status, lasersoft_total, manual_sale_total, manual_gp_estimate, gp_blend_note, sales_source, expenses_source, source, sales_conflict, sales_conflict_excel, checker_flags, details, photo_data, notes, created_at, updated_at, invoice_seq_start, invoice_seq_end, override_log) FROM stdin;
\.


--
-- Data for Name: discount_rules; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.discount_rules (id, role, max_discount_pct, notes, active, created_at) FROM stdin;
\.


--
-- Data for Name: document_inbox; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.document_inbox (id, source, from_ref, original_name, file_path, doc_type, status, extracted, confidence, reader_note, filed_to, filed_id, filed_note, created_at, filed_at, sha256) FROM stdin;
\.


--
-- Data for Name: document_quarantine; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.document_quarantine (id, file_name, ext, mime, bytes, sha256, original_name, source, from_ref, caption, suggested_place, suggested_reason, status, inbox_id, created_at, decided_at, decided_by) FROM stdin;
\.


--
-- Data for Name: document_recipients; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.document_recipients (id, name, role, phone, allowed_types, active, created_at) FROM stdin;
\.


--
-- Data for Name: document_sends; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.document_sends (id, document_id, document_title, recipient_id, purpose, idempotency_key, status, to_last3, detail, requested_by, queue_id, created_at) FROM stdin;
\.


--
-- Data for Name: documents; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.documents (id, type, title, period, created_at, path, sha256, created_by, format, bytes) FROM stdin;
\.


--
-- Data for Name: enquiries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.enquiries (id, date, channel, product_interest, how_found_us, status, notes, created_at) FROM stdin;
\.


--
-- Data for Name: expenses_detail; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.expenses_detail (id, report_date, category, description, amount, created_at) FROM stdin;
\.


--
-- Data for Name: feature_flags; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.feature_flags (id, module_key, category, label, description, is_core, enabled, built, updated_at) FROM stdin;
\.


--
-- Data for Name: fixed_overheads; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.fixed_overheads (id, name, monthly_amount, active, updated_at) FROM stdin;
\.


--
-- Data for Name: grn_bill_extra; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.grn_bill_extra (bill_id, paper_total, lines, updated_at) FROM stdin;
1	0	[]	2026-11-04 11:54:42.598337+00
\.


--
-- Data for Name: grn_records; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.grn_records (id, grn_number, supplier_id, supplier_name, grn_date, item_description, quantity, unit_cost, total_amount, source_file_path, status, notes, created_at, caveat_note, caveat_flag) FROM stdin;
\.


--
-- Data for Name: investor_contacts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.investor_contacts (id, phone, name, lender_name, active, created_at) FROM stdin;
\.


--
-- Data for Name: investor_loan_documents; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.investor_loan_documents (id, loan_id, original_name, stored_name, uploaded_at) FROM stdin;
\.


--
-- Data for Name: investor_loan_payments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.investor_loan_payments (id, loan_id, amount, payment_date, notes, created_at) FROM stdin;
\.


--
-- Data for Name: investor_loans; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.investor_loans (id, lender_name, amount, profit_rate, date_given, due_date, status, notes, created_at, updated_at, qr_outstanding) FROM stdin;
\.


--
-- Data for Name: invoice_receipts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.invoice_receipts (id, report_id, report_date, invoice_no, customer_id, customer_name, customer_phone, status, last_error, sent_at, created_at, updated_at, bill_id) FROM stdin;
\.


--
-- Data for Name: login_audit; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.login_audit (id, username, success, ip, reason, attempted_at) FROM stdin;
\.


--
-- Data for Name: market_purchases; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.market_purchases (id, purchase_date, item, customer, buy_cost, sell_price, bill_number, note, voided, created_at) FROM stdin;
\.


--
-- Data for Name: menu_config; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.menu_config (item_key, label, visible, sort_order, updated_by, updated_at) FROM stdin;
\.


--
-- Data for Name: money_allocations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.money_allocations (id, label, category, amount, planned_date, status, notes, created_at) FROM stdin;
\.


--
-- Data for Name: notification_dismissals; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notification_dismissals (id, category, ref_id, due_date, dismissed_at) FROM stdin;
\.


--
-- Data for Name: notify_queue; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notify_queue (id, source, body, created_at, sent_day) FROM stdin;
1	brief	MORNING UPDATE 2026-11-04\n\nYESTERDAY (2026-11-03)\nDaily summary was not entered.\n\nTODAY\nBACKUP: no backup file found!\n\nTHIS WEEK\nChanged in the last day: Auto new window: heavy window opens its successor with create_session (rule 7), handoff text updated | GRN receiving: Arrived tick, short, return, damage; stock and total follow received qty; paper total and difference kept; screen stays editable after OK; sticky save bar | Handoff: CLAUDE.md and rule 5 point to NOW.md first; HANDOFF_PASTE.md for a new window | Input help app-wide: bracketed hint text clears on click, 0 selects, Enter-next in marked forms; GRN workbench hint numbers cleaned | Extra admin login (royalbathhub1) via config; website: 3D RBH logo hero, light colour, scroll reveal	2026-11-04 11:40:16.206604+00	\N
2	checklist	☀️ TODAY\n🔢 Count today: Taps (check the shelf against the app)\n✅ AUDIT GREEN: 16 rules hold (1 heads-up: R15)	2026-11-04 11:55:13.50171+00	\N
\.


--
-- Data for Name: policy_notes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.policy_notes (id, date, topic, summary, source_url, price_risk, verified, created_at) FROM stdin;
\.


--
-- Data for Name: pos_bill_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.pos_bill_history (id, bill_id, action, reason, changed_by, changed_at, old_version) FROM stdin;
\.


--
-- Data for Name: pos_bill_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.pos_bill_items (id, bill_id, item_name, qty, unit_price, line_total, item_code) FROM stdin;
\.


--
-- Data for Name: pos_bill_payments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.pos_bill_payments (id, bill_id, method, amount, reference) FROM stdin;
\.


--
-- Data for Name: pos_bill_voids; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.pos_bill_voids (bill_id, reason, voided_by, voided_at, stock_restored) FROM stdin;
\.


--
-- Data for Name: pos_bills; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.pos_bills (id, bill_number, customer_name, customer_phone, subtotal, discount_pct, discount_amount, total, payment_method, notes, created_at, discount_override, source, attachment_path) FROM stdin;
1	T1	Test	\N	5000.00	0.00	0.00	5000.00	cash	\N	2026-11-04 11:54:42.706343	f	pos	\N
2	T2	Test2	\N	7000.00	0.00	0.00	7000.00	card	\N	2026-11-04 11:54:42.706343	f	pos	\N
\.


--
-- Data for Name: pos_cheque_registered; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.pos_cheque_registered (payment_id, cheque_id, registered_at) FROM stdin;
\.


--
-- Data for Name: pos_quotation_billed; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.pos_quotation_billed (bill_id, quotation_id) FROM stdin;
\.


--
-- Data for Name: price_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.price_history (id, item_code, old_price, new_price, changed_by, changed_at, reason) FROM stdin;
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.products (id, item_code, name, category, stock_level, reorder_threshold, selling_price, avg_cost, photo_url, active, vendor_code) FROM stdin;
1	901	ZZTEST BASIN MIXER	Taps	5	2	1234	22000	\N	t	\N
\.


--
-- Data for Name: pur_landed_costs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.pur_landed_costs (id, po_id, po_total, freight, duty, other_costs, total_landed_cost, notes, created_at) FROM stdin;
\.


--
-- Data for Name: pur_purchase_orders; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.pur_purchase_orders (id, po_number, supplier_id, supplier_name, po_date, expected_date, total_amount, notes, status, linked_grn_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: pur_shipments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.pur_shipments (id, shipment_ref, supplier_id, supplier_name, po_id, origin_port, eta_date, status, notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: pur_supplier_prices; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.pur_supplier_prices (id, item_description, supplier_id, supplier_name, unit_cost, quoted_date, notes) FROM stdin;
\.


--
-- Data for Name: quotation_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.quotation_items (id, quotation_id, product_id, item_code, description, qty, unit_price, line_total, sort_order) FROM stdin;
\.


--
-- Data for Name: quotations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.quotations (id, customer_id, quote_date, valid_until, status, subtotal, discount, total, notes, created_by, created_at, quote_no) FROM stdin;
\.


--
-- Data for Name: receipt_images; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.receipt_images (id, queue_id, bill_no, file_name, width, height, bytes, created_at) FROM stdin;
\.


--
-- Data for Name: receipt_queue; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.receipt_queue (id, customer_phone, sale_reference, amount, status, created_at, sent_at) FROM stdin;
\.


--
-- Data for Name: record_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.record_history (id, module, record_id, action, changed_by, changed_at, reason, old_version, new_version) FROM stdin;
\.


--
-- Data for Name: record_voids; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.record_voids (id, module, record_id, reason, voided_by, voided_at) FROM stdin;
\.


--
-- Data for Name: reply_drafts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.reply_drafts (id, channel, customer_ref, incoming_text, draft_text, status, approved_at, created_at) FROM stdin;
\.


--
-- Data for Name: sal_cheque_cover; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sal_cheque_cover (cheque_id, covered_at) FROM stdin;
\.


--
-- Data for Name: sal_month_close; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sal_month_close (ym, net, savings, colleague, owner_comm, keep, adj_applied, closed_at) FROM stdin;
\.


--
-- Data for Name: sal_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sal_settings (key, value) FROM stdin;
\.


--
-- Data for Name: sal_setup_costs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sal_setup_costs (id, label, amount, paid_on, status, note) FROM stdin;
\.


--
-- Data for Name: sale_commissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sale_commissions (id, staff_id, entry_type, sale_date, amount, commission_pct, commission_amount, linked_sale_id, reference_note, notes, created_at) FROM stdin;
\.


--
-- Data for Name: session; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.session (sid, sess, expire) FROM stdin;
bpzE9n4lHGboLkNvIkGEWYj88RTEfHSI	{"cookie":{"originalMaxAge":43200000,"expires":"2026-11-04T23:55:04.185Z","secure":false,"httpOnly":true,"path":"/"},"user":{"id":1,"username":"qa_admin","name":"QA Admin","role":"admin","staff_id":null}}	2026-11-05 05:25:07
4Jpu9btphDFODC9DXCyKYuXPxTWe6lr7	{"cookie":{"originalMaxAge":43200000,"expires":"2026-11-04T23:40:19.283Z","secure":false,"httpOnly":true,"path":"/"},"user":{"id":1,"username":"qa_admin","name":"QA Admin","role":"admin","staff_id":null}}	2026-11-05 05:10:20
HDaYw_VsfnAkWE2iQwd3m72JiXElXulH	{"cookie":{"originalMaxAge":43200000,"expires":"2026-11-04T23:40:54.263Z","secure":false,"httpOnly":true,"path":"/"},"user":{"id":1,"username":"qa_admin","name":"QA Admin","role":"admin","staff_id":null}}	2026-11-05 05:10:55
moGrl6ng2_G032K1ku2fDPw1_7fZZ5Zr	{"cookie":{"originalMaxAge":43200000,"expires":"2026-11-04T23:40:54.277Z","secure":false,"httpOnly":true,"path":"/"},"user":{"id":1,"username":"qa_admin","name":"QA Admin","role":"admin","staff_id":null}}	2026-11-05 05:10:55
ms8Y1p24ZQsdEIbyrtQBiWlC0S4sSOYS	{"cookie":{"originalMaxAge":43200000,"expires":"2026-11-04T23:43:01.017Z","secure":false,"httpOnly":true,"path":"/"},"user":{"id":1,"username":"qa_admin","name":"QA Admin","role":"admin","staff_id":null}}	2026-11-05 05:13:03
uYm1B7pz_-g_Gxr9XscpFo5NGnz-d7CX	{"cookie":{"originalMaxAge":43200000,"expires":"2026-11-04T23:39:57.580Z","secure":false,"httpOnly":true,"path":"/"},"user":{"id":1,"username":"qa_admin","name":"QA Admin","role":"admin","staff_id":null}}	2026-11-05 05:09:59
YnokSfcVFw7CSjd9isc4qaL2oEVCrlJs	{"cookie":{"originalMaxAge":43200000,"expires":"2026-11-04T23:43:19.078Z","secure":false,"httpOnly":true,"path":"/"},"user":{"id":1,"username":"qa_admin","name":"QA Admin","role":"admin","staff_id":null}}	2026-11-05 05:13:20
Q9UGHJU8U2mMlhjaFVcBDr5QaGckp7qC	{"cookie":{"originalMaxAge":43200000,"expires":"2026-11-04T23:42:20.850Z","secure":false,"httpOnly":true,"path":"/"},"user":{"id":1,"username":"qa_admin","name":"QA Admin","role":"admin","staff_id":null}}	2026-11-05 05:12:23
oweMJpRPfJTg4b15McP_SCbpAeTjnAR4	{"cookie":{"originalMaxAge":43200000,"expires":"2026-11-04T23:41:44.633Z","secure":false,"httpOnly":true,"path":"/"},"user":{"id":1,"username":"qa_admin","name":"QA Admin","role":"admin","staff_id":null}}	2026-11-05 05:11:47
4XhHI19CaQOZJ9veYmEhQa8UV6dt90Kw	{"cookie":{"originalMaxAge":43200000,"expires":"2026-11-04T23:40:06.622Z","secure":false,"httpOnly":true,"path":"/"},"user":{"id":1,"username":"qa_admin","name":"QA Admin","role":"admin","staff_id":null}}	2026-11-05 05:10:08
rIm2-oCR1dQ51OB7-I8-TxSEF41KHDOI	{"cookie":{"originalMaxAge":43200000,"expires":"2026-11-04T23:43:26.925Z","secure":false,"httpOnly":true,"path":"/"},"user":{"id":1,"username":"qa_admin","name":"QA Admin","role":"admin","staff_id":null}}	2026-11-05 05:13:27
uBGWiAALeN_W6nPmUsDRtdj2sm5OVpDg	{"cookie":{"originalMaxAge":43200000,"expires":"2026-11-04T23:41:00.232Z","secure":false,"httpOnly":true,"path":"/"},"user":{"id":1,"username":"qa_admin","name":"QA Admin","role":"admin","staff_id":null}}	2026-11-05 05:11:02
v-EBYJX5IdsFuC1ZOFfVYcXUkgLXH77U	{"cookie":{"originalMaxAge":43200000,"expires":"2026-11-04T23:41:44.127Z","secure":false,"httpOnly":true,"path":"/"},"user":{"id":1,"username":"qa_admin","name":"QA Admin","role":"admin","staff_id":null}}	2026-11-05 05:11:45
Qo3Dcjk_ZYegYpEHrq3ptzD5WUcnwp6w	{"cookie":{"originalMaxAge":43200000,"expires":"2026-11-04T23:43:26.934Z","secure":false,"httpOnly":true,"path":"/"},"user":{"id":1,"username":"qa_admin","name":"QA Admin","role":"admin","staff_id":null}}	2026-11-05 05:13:27
FtKoIGn4WptlmD21-q_L6NhwHARQIoGQ	{"cookie":{"originalMaxAge":43200000,"expires":"2026-11-04T23:54:50.692Z","secure":false,"httpOnly":true,"path":"/"},"user":{"id":1,"username":"qa_admin","name":"QA Admin","role":"admin","staff_id":null}}	2026-11-05 05:24:55
zIGBnPEmIuQgHZzBJtIwi7UDg_3cK9Ub	{"cookie":{"originalMaxAge":43200000,"expires":"2026-11-04T23:43:31.969Z","secure":false,"httpOnly":true,"path":"/"},"user":{"id":1,"username":"qa_admin","name":"QA Admin","role":"admin","staff_id":null}}	2026-11-05 05:13:37
LgUhyHRRBdZBLvNFSR_78jq4pfQLR6Kb	{"cookie":{"originalMaxAge":43200000,"expires":"2026-11-04T23:54:42.627Z","secure":false,"httpOnly":true,"path":"/"},"user":{"id":1,"username":"qa_admin","name":"QA Admin","role":"admin","staff_id":null}}	2026-11-05 05:24:43
RbBtuH6EA7blhygpN92bpzQmH62m8IFu	{"cookie":{"originalMaxAge":43200000,"expires":"2026-11-04T23:54:42.654Z","secure":false,"httpOnly":true,"path":"/"},"user":{"id":1,"username":"qa_admin","name":"QA Admin","role":"admin","staff_id":null}}	2026-11-05 05:24:43
Ysqq184-VsNIZtrSqOgiYnk6pj92z2X9	{"cookie":{"originalMaxAge":43200000,"expires":"2026-11-04T23:54:42.730Z","secure":false,"httpOnly":true,"path":"/"},"user":{"id":1,"username":"qa_admin","name":"QA Admin","role":"admin","staff_id":null}}	2026-11-05 05:24:43
GoPlJ-tmFVlq6QF4tg-lOxyQ6V6pBpIr	{"cookie":{"originalMaxAge":43200000,"expires":"2026-11-04T23:54:42.744Z","secure":false,"httpOnly":true,"path":"/"},"user":{"id":1,"username":"qa_admin","name":"QA Admin","role":"admin","staff_id":null}}	2026-11-05 05:24:43
KXDTzUvtHebGxI5mt7himZvC-oQY9-r5	{"cookie":{"originalMaxAge":43200000,"expires":"2026-11-05T00:10:37.508Z","secure":false,"httpOnly":true,"path":"/"},"user":{"id":1,"username":"qa_admin","name":"QA Admin","role":"admin","staff_id":null}}	2026-11-05 05:40:49
\.


--
-- Data for Name: site_text; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.site_text (key, value) FROM stdin;
\.


--
-- Data for Name: site_tiles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.site_tiles (id, name, size, finish, grp, photo_file, visible, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: staff; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.staff (id, name, phone, role, base_salary, commission_pct, join_date, active) FROM stdin;
\.


--
-- Data for Name: staff_attendance; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.staff_attendance (id, staff_id, work_date, status, notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: staff_leave; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.staff_leave (id, staff_id, leave_start, leave_end, leave_type, reason, status, created_at) FROM stdin;
\.


--
-- Data for Name: staff_loans; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.staff_loans (id, staff_id, loan_date, amount, repaid, type, notes) FROM stdin;
\.


--
-- Data for Name: staff_salary; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.staff_salary (id, staff_id, pay_date, amount, commission, period_start, period_end, notes) FROM stdin;
\.


--
-- Data for Name: stock_adjustments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stock_adjustments (id, stock_item_id, delta, reason, notes, created_at) FROM stdin;
\.


--
-- Data for Name: stock_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stock_items (id, item_name, unit, current_qty, reorder_level, notes, updated_at) FROM stdin;
\.


--
-- Data for Name: supplier_payments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.supplier_payments (id, supplier_id, amount, pay_date, method, notes) FROM stdin;
\.


--
-- Data for Name: suppliers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.suppliers (id, name, phone, category, notes, active, contact_person, whatsapp, email, address, city, tin, default_credit_days, pay_note) FROM stdin;
1	Cool Lanka (Pvt) Ltd	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N
\.


--
-- Data for Name: sync_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sync_log (id, record_type, status, created_at, method, path, response_status, response_body, device, queued_at, detail, resolved_by, resolved_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, username, name, password_hash, role, staff_id, active, totp_secret, totp_enabled, created_at) FROM stdin;
1	qa_admin	QA Admin	x	admin	\N	t	\N	f	2026-11-04 11:39:05.346097+00
\.


--
-- Data for Name: vendor_bill_cheques; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.vendor_bill_cheques (id, branch_id, bill_id, cheque_no, bank, payee, amount, cheque_date, due_date, same_bank, status, cleared_at, photo_path, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: vendor_bills; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.vendor_bills (id, branch_id, vendor_name, bill_no, bill_date, due_date, total, grn_id, photo_path, notes, voided, created_by, created_at) FROM stdin;
1	1	Cool Lanka (Pvt) Ltd	001	2026-10-28	2027-01-26	527000.00	\N	\N	Bill only (no stock); paid by BILL; 90 credit days	f	grn-workbench	2026-11-04 11:54:42.598337+00
\.


--
-- Data for Name: vendor_credit_notes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.vendor_credit_notes (id, branch_id, bill_id, note_no, amount, note_date, reason, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: vendor_payments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.vendor_payments (id, branch_id, bill_id, amount, method, paid_at, note, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: vendor_pending_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.vendor_pending_items (id, bill_no, vendor_name, ref, item_name, qty, unit_cost, amount, status, created_at, delivered_at, note) FROM stdin;
\.


--
-- Data for Name: viewer_access_requests; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.viewer_access_requests (id, requester_name, requester_contact, status, access_token, created_at, approved_at) FROM stdin;
\.


--
-- Data for Name: whatsapp_draft_entries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.whatsapp_draft_entries (id, from_number, photo_path, report_date, total_sale, cash_sale, card_sale, online_sale, credit_sale, total_expenses, expense_items, confidence, ocr_notes, ocr_raw, status, confirmed_at, created_at) FROM stdin;
\.


--
-- Data for Name: whatsapp_notified; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.whatsapp_notified (id, category, ref_id, due_date, notified_at) FROM stdin;
\.


--
-- Name: acc_bank_transactions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.acc_bank_transactions_id_seq', 1, false);


--
-- Name: acc_expense_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.acc_expense_categories_id_seq', 1, false);


--
-- Name: acc_journal_entries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.acc_journal_entries_id_seq', 1, false);


--
-- Name: acc_petty_cash_txns_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.acc_petty_cash_txns_id_seq', 1, false);


--
-- Name: acc_year_end_closings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.acc_year_end_closings_id_seq', 1, false);


--
-- Name: admin_audit_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.admin_audit_id_seq', 1, false);


--
-- Name: agent_checks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.agent_checks_id_seq', 1, false);


--
-- Name: agent_rules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.agent_rules_id_seq', 5, true);


--
-- Name: alerts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.alerts_id_seq', 1, false);


--
-- Name: attachments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.attachments_id_seq', 1, false);


--
-- Name: audit_invoice_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.audit_invoice_items_id_seq', 1, false);


--
-- Name: bank_accounts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.bank_accounts_id_seq', 1, false);


--
-- Name: branches_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.branches_id_seq', 1, false);


--
-- Name: cheque_register_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.cheque_register_id_seq', 1, false);


--
-- Name: cheques_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.cheques_id_seq', 1, false);


--
-- Name: competitor_checks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.competitor_checks_id_seq', 1, false);


--
-- Name: competitors_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.competitors_id_seq', 13, true);


--
-- Name: content_posts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.content_posts_id_seq', 1, false);


--
-- Name: conversations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.conversations_id_seq', 1, false);


--
-- Name: credit_customers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.credit_customers_id_seq', 1, false);


--
-- Name: customer_credit_limits_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.customer_credit_limits_id_seq', 1, false);


--
-- Name: customers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.customers_id_seq', 1, false);


--
-- Name: daily_cash_plan_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.daily_cash_plan_id_seq', 1, false);


--
-- Name: daily_payment_breakdown_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.daily_payment_breakdown_id_seq', 1, false);


--
-- Name: daily_reports_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.daily_reports_id_seq', 1, false);


--
-- Name: daily_summary_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.daily_summary_id_seq', 1, false);


--
-- Name: discount_rules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.discount_rules_id_seq', 1, false);


--
-- Name: document_inbox_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.document_inbox_id_seq', 1, false);


--
-- Name: document_quarantine_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.document_quarantine_id_seq', 1, false);


--
-- Name: document_recipients_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.document_recipients_id_seq', 1, false);


--
-- Name: document_sends_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.document_sends_id_seq', 1, false);


--
-- Name: documents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.documents_id_seq', 1, false);


--
-- Name: enquiries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.enquiries_id_seq', 1, false);


--
-- Name: expenses_detail_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.expenses_detail_id_seq', 1, false);


--
-- Name: feature_flags_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.feature_flags_id_seq', 1, false);


--
-- Name: fixed_overheads_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.fixed_overheads_id_seq', 1, false);


--
-- Name: grn_records_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.grn_records_id_seq', 1, false);


--
-- Name: investor_contacts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.investor_contacts_id_seq', 1, false);


--
-- Name: investor_loan_documents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.investor_loan_documents_id_seq', 1, false);


--
-- Name: investor_loan_payments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.investor_loan_payments_id_seq', 1, false);


--
-- Name: investor_loans_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.investor_loans_id_seq', 1, false);


--
-- Name: invoice_receipts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.invoice_receipts_id_seq', 1, false);


--
-- Name: login_audit_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.login_audit_id_seq', 1, false);


--
-- Name: market_purchases_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.market_purchases_id_seq', 1, false);


--
-- Name: money_allocations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.money_allocations_id_seq', 1, false);


--
-- Name: notification_dismissals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.notification_dismissals_id_seq', 1, false);


--
-- Name: notify_queue_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.notify_queue_id_seq', 2, true);


--
-- Name: policy_notes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.policy_notes_id_seq', 1, false);


--
-- Name: pos_bill_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.pos_bill_history_id_seq', 1, false);


--
-- Name: pos_bill_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.pos_bill_items_id_seq', 1, false);


--
-- Name: pos_bill_payments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.pos_bill_payments_id_seq', 1, false);


--
-- Name: pos_bills_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.pos_bills_id_seq', 2, true);


--
-- Name: price_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.price_history_id_seq', 1, false);


--
-- Name: products_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.products_id_seq', 1, true);


--
-- Name: pur_landed_costs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.pur_landed_costs_id_seq', 1, false);


--
-- Name: pur_purchase_orders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.pur_purchase_orders_id_seq', 1, false);


--
-- Name: pur_shipments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.pur_shipments_id_seq', 1, false);


--
-- Name: pur_supplier_prices_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.pur_supplier_prices_id_seq', 1, false);


--
-- Name: quotation_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.quotation_items_id_seq', 1, false);


--
-- Name: quotations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.quotations_id_seq', 1, false);


--
-- Name: receipt_images_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.receipt_images_id_seq', 1, false);


--
-- Name: receipt_queue_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.receipt_queue_id_seq', 1, false);


--
-- Name: record_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.record_history_id_seq', 1, false);


--
-- Name: record_voids_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.record_voids_id_seq', 1, false);


--
-- Name: reply_drafts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.reply_drafts_id_seq', 1, false);


--
-- Name: sal_setup_costs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sal_setup_costs_id_seq', 1, false);


--
-- Name: sale_commissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sale_commissions_id_seq', 1, false);


--
-- Name: site_tiles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.site_tiles_id_seq', 1, false);


--
-- Name: staff_attendance_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.staff_attendance_id_seq', 1, false);


--
-- Name: staff_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.staff_id_seq', 1, false);


--
-- Name: staff_leave_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.staff_leave_id_seq', 1, false);


--
-- Name: staff_loans_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.staff_loans_id_seq', 1, false);


--
-- Name: staff_salary_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.staff_salary_id_seq', 1, false);


--
-- Name: stock_adjustments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.stock_adjustments_id_seq', 1, false);


--
-- Name: stock_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.stock_items_id_seq', 1, false);


--
-- Name: supplier_payments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.supplier_payments_id_seq', 1, false);


--
-- Name: suppliers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.suppliers_id_seq', 1, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_id_seq', 3, true);


--
-- Name: vendor_bill_cheques_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.vendor_bill_cheques_id_seq', 1, true);


--
-- Name: vendor_bills_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.vendor_bills_id_seq', 1, true);


--
-- Name: vendor_credit_notes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.vendor_credit_notes_id_seq', 1, false);


--
-- Name: vendor_payments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.vendor_payments_id_seq', 1, false);


--
-- Name: vendor_pending_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.vendor_pending_items_id_seq', 1, false);


--
-- Name: viewer_access_requests_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.viewer_access_requests_id_seq', 1, false);


--
-- Name: whatsapp_draft_entries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.whatsapp_draft_entries_id_seq', 1, false);


--
-- Name: whatsapp_notified_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.whatsapp_notified_id_seq', 1, false);


--
-- Name: acc_bank_transactions acc_bank_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.acc_bank_transactions
    ADD CONSTRAINT acc_bank_transactions_pkey PRIMARY KEY (id);


--
-- Name: acc_chart_of_accounts acc_chart_of_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.acc_chart_of_accounts
    ADD CONSTRAINT acc_chart_of_accounts_pkey PRIMARY KEY (account_code);


--
-- Name: acc_expense_categories acc_expense_categories_category_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.acc_expense_categories
    ADD CONSTRAINT acc_expense_categories_category_name_key UNIQUE (category_name);


--
-- Name: acc_expense_categories acc_expense_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.acc_expense_categories
    ADD CONSTRAINT acc_expense_categories_pkey PRIMARY KEY (id);


--
-- Name: acc_journal_entries acc_journal_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.acc_journal_entries
    ADD CONSTRAINT acc_journal_entries_pkey PRIMARY KEY (id);


--
-- Name: acc_petty_cash_txns acc_petty_cash_txns_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.acc_petty_cash_txns
    ADD CONSTRAINT acc_petty_cash_txns_pkey PRIMARY KEY (id);


--
-- Name: acc_year_end_closings acc_year_end_closings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.acc_year_end_closings
    ADD CONSTRAINT acc_year_end_closings_pkey PRIMARY KEY (id);


--
-- Name: admin_audit admin_audit_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_audit
    ADD CONSTRAINT admin_audit_pkey PRIMARY KEY (id);


--
-- Name: agent_checks agent_checks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_checks
    ADD CONSTRAINT agent_checks_pkey PRIMARY KEY (id);


--
-- Name: agent_rules agent_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_rules
    ADD CONSTRAINT agent_rules_pkey PRIMARY KEY (id);


--
-- Name: alerts alerts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_pkey PRIMARY KEY (id);


--
-- Name: app_settings app_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.app_settings
    ADD CONSTRAINT app_settings_pkey PRIMARY KEY (key);


--
-- Name: attachments attachments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attachments
    ADD CONSTRAINT attachments_pkey PRIMARY KEY (id);


--
-- Name: audit_baseline audit_baseline_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_baseline
    ADD CONSTRAINT audit_baseline_pkey PRIMARY KEY (item_code);


--
-- Name: audit_invoice_items audit_invoice_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_invoice_items
    ADD CONSTRAINT audit_invoice_items_pkey PRIMARY KEY (id);


--
-- Name: automation_runs automation_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.automation_runs
    ADD CONSTRAINT automation_runs_pkey PRIMARY KEY (job, day);


--
-- Name: bank_accounts bank_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bank_accounts
    ADD CONSTRAINT bank_accounts_pkey PRIMARY KEY (id);


--
-- Name: bank_holidays bank_holidays_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bank_holidays
    ADD CONSTRAINT bank_holidays_pkey PRIMARY KEY (day);


--
-- Name: branches branches_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.branches
    ADD CONSTRAINT branches_pkey PRIMARY KEY (id);


--
-- Name: catalogue_web catalogue_web_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.catalogue_web
    ADD CONSTRAINT catalogue_web_pkey PRIMARY KEY (item_code);


--
-- Name: cheque_alerts_sent cheque_alerts_sent_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cheque_alerts_sent
    ADD CONSTRAINT cheque_alerts_sent_pkey PRIMARY KEY (cheque_id, alert_date);


--
-- Name: cheque_deposits cheque_deposits_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cheque_deposits
    ADD CONSTRAINT cheque_deposits_pkey PRIMARY KEY (cheque_id);


--
-- Name: cheque_personal cheque_personal_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cheque_personal
    ADD CONSTRAINT cheque_personal_pkey PRIMARY KEY (cheque_id);


--
-- Name: cheque_register cheque_register_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cheque_register
    ADD CONSTRAINT cheque_register_pkey PRIMARY KEY (id);


--
-- Name: cheques cheques_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cheques
    ADD CONSTRAINT cheques_pkey PRIMARY KEY (id);


--
-- Name: competitor_checks competitor_checks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.competitor_checks
    ADD CONSTRAINT competitor_checks_pkey PRIMARY KEY (id);


--
-- Name: competitors competitors_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.competitors
    ADD CONSTRAINT competitors_pkey PRIMARY KEY (id);


--
-- Name: content_posts content_posts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.content_posts
    ADD CONSTRAINT content_posts_pkey PRIMARY KEY (id);


--
-- Name: conversations conversations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT conversations_pkey PRIMARY KEY (id);


--
-- Name: credit_customers credit_customers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credit_customers
    ADD CONSTRAINT credit_customers_pkey PRIMARY KEY (id);


--
-- Name: customer_credit_limits customer_credit_limits_customer_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_credit_limits
    ADD CONSTRAINT customer_credit_limits_customer_name_key UNIQUE (customer_name);


--
-- Name: customer_credit_limits customer_credit_limits_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_credit_limits
    ADD CONSTRAINT customer_credit_limits_pkey PRIMARY KEY (id);


--
-- Name: customers customers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_pkey PRIMARY KEY (id);


--
-- Name: daily_breakdown_settings daily_breakdown_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.daily_breakdown_settings
    ADD CONSTRAINT daily_breakdown_settings_pkey PRIMARY KEY (id);


--
-- Name: daily_cash_plan daily_cash_plan_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.daily_cash_plan
    ADD CONSTRAINT daily_cash_plan_pkey PRIMARY KEY (id);


--
-- Name: daily_cash_plan daily_cash_plan_report_date_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.daily_cash_plan
    ADD CONSTRAINT daily_cash_plan_report_date_key UNIQUE (report_date);


--
-- Name: daily_entry_live daily_entry_live_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.daily_entry_live
    ADD CONSTRAINT daily_entry_live_pkey PRIMARY KEY (entry_date);


--
-- Name: daily_payment_breakdown daily_payment_breakdown_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.daily_payment_breakdown
    ADD CONSTRAINT daily_payment_breakdown_pkey PRIMARY KEY (id);


--
-- Name: daily_payment_breakdown daily_payment_breakdown_report_date_mode_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.daily_payment_breakdown
    ADD CONSTRAINT daily_payment_breakdown_report_date_mode_key UNIQUE (report_date, mode);


--
-- Name: daily_reports daily_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.daily_reports
    ADD CONSTRAINT daily_reports_pkey PRIMARY KEY (id);


--
-- Name: daily_summary daily_summary_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.daily_summary
    ADD CONSTRAINT daily_summary_pkey PRIMARY KEY (id);


--
-- Name: daily_summary daily_summary_report_date_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.daily_summary
    ADD CONSTRAINT daily_summary_report_date_key UNIQUE (report_date);


--
-- Name: discount_rules discount_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.discount_rules
    ADD CONSTRAINT discount_rules_pkey PRIMARY KEY (id);


--
-- Name: document_inbox document_inbox_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_inbox
    ADD CONSTRAINT document_inbox_pkey PRIMARY KEY (id);


--
-- Name: document_quarantine document_quarantine_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_quarantine
    ADD CONSTRAINT document_quarantine_pkey PRIMARY KEY (id);


--
-- Name: document_recipients document_recipients_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_recipients
    ADD CONSTRAINT document_recipients_pkey PRIMARY KEY (id);


--
-- Name: document_sends document_sends_idempotency_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_sends
    ADD CONSTRAINT document_sends_idempotency_key_key UNIQUE (idempotency_key);


--
-- Name: document_sends document_sends_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_sends
    ADD CONSTRAINT document_sends_pkey PRIMARY KEY (id);


--
-- Name: documents documents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_pkey PRIMARY KEY (id);


--
-- Name: enquiries enquiries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.enquiries
    ADD CONSTRAINT enquiries_pkey PRIMARY KEY (id);


--
-- Name: expenses_detail expenses_detail_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.expenses_detail
    ADD CONSTRAINT expenses_detail_pkey PRIMARY KEY (id);


--
-- Name: feature_flags feature_flags_module_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feature_flags
    ADD CONSTRAINT feature_flags_module_key_key UNIQUE (module_key);


--
-- Name: feature_flags feature_flags_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feature_flags
    ADD CONSTRAINT feature_flags_pkey PRIMARY KEY (id);


--
-- Name: fixed_overheads fixed_overheads_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fixed_overheads
    ADD CONSTRAINT fixed_overheads_pkey PRIMARY KEY (id);


--
-- Name: grn_bill_extra grn_bill_extra_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.grn_bill_extra
    ADD CONSTRAINT grn_bill_extra_pkey PRIMARY KEY (bill_id);


--
-- Name: grn_records grn_records_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.grn_records
    ADD CONSTRAINT grn_records_pkey PRIMARY KEY (id);


--
-- Name: investor_contacts investor_contacts_phone_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.investor_contacts
    ADD CONSTRAINT investor_contacts_phone_key UNIQUE (phone);


--
-- Name: investor_contacts investor_contacts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.investor_contacts
    ADD CONSTRAINT investor_contacts_pkey PRIMARY KEY (id);


--
-- Name: investor_loan_documents investor_loan_documents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.investor_loan_documents
    ADD CONSTRAINT investor_loan_documents_pkey PRIMARY KEY (id);


--
-- Name: investor_loan_payments investor_loan_payments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.investor_loan_payments
    ADD CONSTRAINT investor_loan_payments_pkey PRIMARY KEY (id);


--
-- Name: investor_loans investor_loans_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.investor_loans
    ADD CONSTRAINT investor_loans_pkey PRIMARY KEY (id);


--
-- Name: invoice_receipts invoice_receipts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_receipts
    ADD CONSTRAINT invoice_receipts_pkey PRIMARY KEY (id);


--
-- Name: login_audit login_audit_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.login_audit
    ADD CONSTRAINT login_audit_pkey PRIMARY KEY (id);


--
-- Name: market_purchases market_purchases_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.market_purchases
    ADD CONSTRAINT market_purchases_pkey PRIMARY KEY (id);


--
-- Name: menu_config menu_config_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.menu_config
    ADD CONSTRAINT menu_config_pkey PRIMARY KEY (item_key);


--
-- Name: money_allocations money_allocations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.money_allocations
    ADD CONSTRAINT money_allocations_pkey PRIMARY KEY (id);


--
-- Name: notification_dismissals notification_dismissals_category_ref_id_due_date_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_dismissals
    ADD CONSTRAINT notification_dismissals_category_ref_id_due_date_key UNIQUE (category, ref_id, due_date);


--
-- Name: notification_dismissals notification_dismissals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_dismissals
    ADD CONSTRAINT notification_dismissals_pkey PRIMARY KEY (id);


--
-- Name: notify_queue notify_queue_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notify_queue
    ADD CONSTRAINT notify_queue_pkey PRIMARY KEY (id);


--
-- Name: policy_notes policy_notes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.policy_notes
    ADD CONSTRAINT policy_notes_pkey PRIMARY KEY (id);


--
-- Name: pos_bill_history pos_bill_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_bill_history
    ADD CONSTRAINT pos_bill_history_pkey PRIMARY KEY (id);


--
-- Name: pos_bill_items pos_bill_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_bill_items
    ADD CONSTRAINT pos_bill_items_pkey PRIMARY KEY (id);


--
-- Name: pos_bill_payments pos_bill_payments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_bill_payments
    ADD CONSTRAINT pos_bill_payments_pkey PRIMARY KEY (id);


--
-- Name: pos_bill_voids pos_bill_voids_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_bill_voids
    ADD CONSTRAINT pos_bill_voids_pkey PRIMARY KEY (bill_id);


--
-- Name: pos_bills pos_bills_bill_number_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_bills
    ADD CONSTRAINT pos_bills_bill_number_key UNIQUE (bill_number);


--
-- Name: pos_bills pos_bills_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_bills
    ADD CONSTRAINT pos_bills_pkey PRIMARY KEY (id);


--
-- Name: pos_cheque_registered pos_cheque_registered_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_cheque_registered
    ADD CONSTRAINT pos_cheque_registered_pkey PRIMARY KEY (payment_id);


--
-- Name: pos_quotation_billed pos_quotation_billed_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_quotation_billed
    ADD CONSTRAINT pos_quotation_billed_pkey PRIMARY KEY (bill_id);


--
-- Name: price_history price_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.price_history
    ADD CONSTRAINT price_history_pkey PRIMARY KEY (id);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: pur_landed_costs pur_landed_costs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pur_landed_costs
    ADD CONSTRAINT pur_landed_costs_pkey PRIMARY KEY (id);


--
-- Name: pur_purchase_orders pur_purchase_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pur_purchase_orders
    ADD CONSTRAINT pur_purchase_orders_pkey PRIMARY KEY (id);


--
-- Name: pur_purchase_orders pur_purchase_orders_po_number_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pur_purchase_orders
    ADD CONSTRAINT pur_purchase_orders_po_number_key UNIQUE (po_number);


--
-- Name: pur_shipments pur_shipments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pur_shipments
    ADD CONSTRAINT pur_shipments_pkey PRIMARY KEY (id);


--
-- Name: pur_supplier_prices pur_supplier_prices_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pur_supplier_prices
    ADD CONSTRAINT pur_supplier_prices_pkey PRIMARY KEY (id);


--
-- Name: quotation_items quotation_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quotation_items
    ADD CONSTRAINT quotation_items_pkey PRIMARY KEY (id);


--
-- Name: quotations quotations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quotations
    ADD CONSTRAINT quotations_pkey PRIMARY KEY (id);


--
-- Name: receipt_images receipt_images_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.receipt_images
    ADD CONSTRAINT receipt_images_pkey PRIMARY KEY (id);


--
-- Name: receipt_queue receipt_queue_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.receipt_queue
    ADD CONSTRAINT receipt_queue_pkey PRIMARY KEY (id);


--
-- Name: record_history record_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.record_history
    ADD CONSTRAINT record_history_pkey PRIMARY KEY (id);


--
-- Name: record_voids record_voids_module_record_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.record_voids
    ADD CONSTRAINT record_voids_module_record_id_key UNIQUE (module, record_id);


--
-- Name: record_voids record_voids_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.record_voids
    ADD CONSTRAINT record_voids_pkey PRIMARY KEY (id);


--
-- Name: reply_drafts reply_drafts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reply_drafts
    ADD CONSTRAINT reply_drafts_pkey PRIMARY KEY (id);


--
-- Name: sal_cheque_cover sal_cheque_cover_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sal_cheque_cover
    ADD CONSTRAINT sal_cheque_cover_pkey PRIMARY KEY (cheque_id);


--
-- Name: sal_month_close sal_month_close_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sal_month_close
    ADD CONSTRAINT sal_month_close_pkey PRIMARY KEY (ym);


--
-- Name: sal_settings sal_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sal_settings
    ADD CONSTRAINT sal_settings_pkey PRIMARY KEY (key);


--
-- Name: sal_setup_costs sal_setup_costs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sal_setup_costs
    ADD CONSTRAINT sal_setup_costs_pkey PRIMARY KEY (id);


--
-- Name: sale_commissions sale_commissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sale_commissions
    ADD CONSTRAINT sale_commissions_pkey PRIMARY KEY (id);


--
-- Name: session session_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session
    ADD CONSTRAINT session_pkey PRIMARY KEY (sid);


--
-- Name: site_text site_text_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.site_text
    ADD CONSTRAINT site_text_pkey PRIMARY KEY (key);


--
-- Name: site_tiles site_tiles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.site_tiles
    ADD CONSTRAINT site_tiles_pkey PRIMARY KEY (id);


--
-- Name: staff_attendance staff_attendance_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.staff_attendance
    ADD CONSTRAINT staff_attendance_pkey PRIMARY KEY (id);


--
-- Name: staff_attendance staff_attendance_staff_id_work_date_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.staff_attendance
    ADD CONSTRAINT staff_attendance_staff_id_work_date_key UNIQUE (staff_id, work_date);


--
-- Name: staff_leave staff_leave_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.staff_leave
    ADD CONSTRAINT staff_leave_pkey PRIMARY KEY (id);


--
-- Name: staff_loans staff_loans_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.staff_loans
    ADD CONSTRAINT staff_loans_pkey PRIMARY KEY (id);


--
-- Name: staff staff_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.staff
    ADD CONSTRAINT staff_pkey PRIMARY KEY (id);


--
-- Name: staff_salary staff_salary_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.staff_salary
    ADD CONSTRAINT staff_salary_pkey PRIMARY KEY (id);


--
-- Name: stock_adjustments stock_adjustments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_adjustments
    ADD CONSTRAINT stock_adjustments_pkey PRIMARY KEY (id);


--
-- Name: stock_items stock_items_item_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_items
    ADD CONSTRAINT stock_items_item_name_key UNIQUE (item_name);


--
-- Name: stock_items stock_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_items
    ADD CONSTRAINT stock_items_pkey PRIMARY KEY (id);


--
-- Name: supplier_payments supplier_payments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supplier_payments
    ADD CONSTRAINT supplier_payments_pkey PRIMARY KEY (id);


--
-- Name: suppliers suppliers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.suppliers
    ADD CONSTRAINT suppliers_pkey PRIMARY KEY (id);


--
-- Name: sync_log sync_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sync_log
    ADD CONSTRAINT sync_log_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: vendor_bill_cheques vendor_bill_cheques_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vendor_bill_cheques
    ADD CONSTRAINT vendor_bill_cheques_pkey PRIMARY KEY (id);


--
-- Name: vendor_bills vendor_bills_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vendor_bills
    ADD CONSTRAINT vendor_bills_pkey PRIMARY KEY (id);


--
-- Name: vendor_credit_notes vendor_credit_notes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vendor_credit_notes
    ADD CONSTRAINT vendor_credit_notes_pkey PRIMARY KEY (id);


--
-- Name: vendor_payments vendor_payments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vendor_payments
    ADD CONSTRAINT vendor_payments_pkey PRIMARY KEY (id);


--
-- Name: vendor_pending_items vendor_pending_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vendor_pending_items
    ADD CONSTRAINT vendor_pending_items_pkey PRIMARY KEY (id);


--
-- Name: viewer_access_requests viewer_access_requests_access_token_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.viewer_access_requests
    ADD CONSTRAINT viewer_access_requests_access_token_key UNIQUE (access_token);


--
-- Name: viewer_access_requests viewer_access_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.viewer_access_requests
    ADD CONSTRAINT viewer_access_requests_pkey PRIMARY KEY (id);


--
-- Name: whatsapp_draft_entries whatsapp_draft_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.whatsapp_draft_entries
    ADD CONSTRAINT whatsapp_draft_entries_pkey PRIMARY KEY (id);


--
-- Name: whatsapp_notified whatsapp_notified_category_ref_id_due_date_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.whatsapp_notified
    ADD CONSTRAINT whatsapp_notified_category_ref_id_due_date_key UNIQUE (category, ref_id, due_date);


--
-- Name: whatsapp_notified whatsapp_notified_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.whatsapp_notified
    ADD CONSTRAINT whatsapp_notified_pkey PRIMARY KEY (id);


--
-- Name: IDX_session_expire; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_session_expire" ON public.session USING btree (expire);


--
-- Name: admin_audit_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX admin_audit_at_idx ON public.admin_audit USING btree (at DESC);


--
-- Name: attachments_client_uuid_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX attachments_client_uuid_idx ON public.attachments USING btree (client_uuid) WHERE (client_uuid IS NOT NULL);


--
-- Name: attachments_record_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX attachments_record_idx ON public.attachments USING btree (record_type, record_id);


--
-- Name: idx_agent_rules_key; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_agent_rules_key ON public.agent_rules USING btree (rule_key, version);


--
-- Name: idx_document_inbox_sha256; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_document_inbox_sha256 ON public.document_inbox USING btree (sha256);


--
-- Name: idx_invoice_receipts_bill; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_invoice_receipts_bill ON public.invoice_receipts USING btree (bill_id) WHERE (bill_id IS NOT NULL);


--
-- Name: idx_invoice_receipts_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_invoice_receipts_date ON public.invoice_receipts USING btree (report_date);


--
-- Name: idx_vbc_bill; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vbc_bill ON public.vendor_bill_cheques USING btree (bill_id);


--
-- Name: idx_vbc_due; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vbc_due ON public.vendor_bill_cheques USING btree (due_date, status);


--
-- Name: idx_vcn_bill; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vcn_bill ON public.vendor_credit_notes USING btree (bill_id);


--
-- Name: idx_vp_bill; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vp_bill ON public.vendor_payments USING btree (bill_id);


--
-- Name: cheque_register cheque_register_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cheque_register
    ADD CONSTRAINT cheque_register_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.bank_accounts(id);


--
-- Name: investor_loan_documents investor_loan_documents_loan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.investor_loan_documents
    ADD CONSTRAINT investor_loan_documents_loan_id_fkey FOREIGN KEY (loan_id) REFERENCES public.investor_loans(id) ON DELETE CASCADE;


--
-- Name: investor_loan_payments investor_loan_payments_loan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.investor_loan_payments
    ADD CONSTRAINT investor_loan_payments_loan_id_fkey FOREIGN KEY (loan_id) REFERENCES public.investor_loans(id) ON DELETE CASCADE;


--
-- Name: pos_bill_history pos_bill_history_bill_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_bill_history
    ADD CONSTRAINT pos_bill_history_bill_id_fkey FOREIGN KEY (bill_id) REFERENCES public.pos_bills(id);


--
-- Name: pos_bill_items pos_bill_items_bill_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_bill_items
    ADD CONSTRAINT pos_bill_items_bill_id_fkey FOREIGN KEY (bill_id) REFERENCES public.pos_bills(id) ON DELETE CASCADE;


--
-- Name: pos_bill_payments pos_bill_payments_bill_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_bill_payments
    ADD CONSTRAINT pos_bill_payments_bill_id_fkey FOREIGN KEY (bill_id) REFERENCES public.pos_bills(id);


--
-- Name: pos_bill_voids pos_bill_voids_bill_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_bill_voids
    ADD CONSTRAINT pos_bill_voids_bill_id_fkey FOREIGN KEY (bill_id) REFERENCES public.pos_bills(id);


--
-- Name: pos_cheque_registered pos_cheque_registered_payment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_cheque_registered
    ADD CONSTRAINT pos_cheque_registered_payment_id_fkey FOREIGN KEY (payment_id) REFERENCES public.pos_bill_payments(id);


--
-- Name: pos_quotation_billed pos_quotation_billed_bill_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pos_quotation_billed
    ADD CONSTRAINT pos_quotation_billed_bill_id_fkey FOREIGN KEY (bill_id) REFERENCES public.pos_bills(id);


--
-- Name: receipt_images receipt_images_queue_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.receipt_images
    ADD CONSTRAINT receipt_images_queue_id_fkey FOREIGN KEY (queue_id) REFERENCES public.receipt_queue(id);


--
-- Name: sale_commissions sale_commissions_linked_sale_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sale_commissions
    ADD CONSTRAINT sale_commissions_linked_sale_id_fkey FOREIGN KEY (linked_sale_id) REFERENCES public.sale_commissions(id);


--
-- Name: sale_commissions sale_commissions_staff_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sale_commissions
    ADD CONSTRAINT sale_commissions_staff_id_fkey FOREIGN KEY (staff_id) REFERENCES public.staff(id);


--
-- Name: staff_attendance staff_attendance_staff_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.staff_attendance
    ADD CONSTRAINT staff_attendance_staff_id_fkey FOREIGN KEY (staff_id) REFERENCES public.staff(id);


--
-- Name: staff_leave staff_leave_staff_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.staff_leave
    ADD CONSTRAINT staff_leave_staff_id_fkey FOREIGN KEY (staff_id) REFERENCES public.staff(id);


--
-- Name: stock_adjustments stock_adjustments_stock_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_adjustments
    ADD CONSTRAINT stock_adjustments_stock_item_id_fkey FOREIGN KEY (stock_item_id) REFERENCES public.stock_items(id) ON DELETE CASCADE;


--
-- Name: vendor_bill_cheques vendor_bill_cheques_bill_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vendor_bill_cheques
    ADD CONSTRAINT vendor_bill_cheques_bill_id_fkey FOREIGN KEY (bill_id) REFERENCES public.vendor_bills(id);


--
-- Name: vendor_credit_notes vendor_credit_notes_bill_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vendor_credit_notes
    ADD CONSTRAINT vendor_credit_notes_bill_id_fkey FOREIGN KEY (bill_id) REFERENCES public.vendor_bills(id);


--
-- Name: vendor_payments vendor_payments_bill_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vendor_payments
    ADD CONSTRAINT vendor_payments_bill_id_fkey FOREIGN KEY (bill_id) REFERENCES public.vendor_bills(id);


--
-- PostgreSQL database dump complete
--

\unrestrict pohWacphkmIg3Hpnss3VlXtAnIeHIXVEeMxmRxEkg8G5w96vr2p7eWt47nffute

